"""Turn the shipping game files into a .rebornroster: the round-trip fixture and
the seed the site imports once."""
import datetime

from . import VERSION
from . import decals
from .directory import Directory
from .dol import Dol
from .gciso import Iso
from .root import Root
from .tdb import find_db
from .update import write_rebornroster
from .writers import eyes, placement, ujsn
from .writers.teams import COLOR_FIELDS, read_colors

PLAY_EXCLUDE = ("PAWR",)
NFL_TGIDS = range(1, 33)


def load_directory(dol, assume_legacy):
    d = Directory.parse(dol)
    if d is not None:
        return d
    if assume_legacy:
        return Directory.legacy(dol)
    raise ValueError("this base has no data directory")


def roster_dbs(template, streamed):
    return (find_db(template, {"PLAY", "TEAM", "CPAL"}),
            find_db(template, {"PRGR", "CRPP"}),
            find_db(streamed, {"PRGR", "NFDP"}))


def _region(dol, directory, tag):
    e = directory.entries[tag]
    return dol.read(e.address, e.capacity)


def players_doc(template, dol_bytes, directory):
    dol = Dol(dol_bytes)
    play = find_db(template, {"PLAY", "TEAM", "CPAL"}).tables["PLAY"]
    fields = [f.name for f in play.fields if f.name not in PLAY_EXCLUDE]
    codes = eyes.decode_pgidtab(_region(dol, directory, "EYPG"))
    rows = []
    for i in range(play.count):
        r = {f: play.get(template, i, f) for f in fields}
        r["EYEC"] = codes.get(r["PGID"], 0)
        r["vacant"] = False
        rows.append(r)
    return {"format_version": 1, "fields": fields, "rows": rows}


def teams_doc(template, dol_bytes, directory):
    dol = Dol(dol_bytes)
    db = find_db(template, {"PLAY", "TEAM", "CPAL"})
    team, cpal = db.tables["TEAM"], db.tables["CPAL"]
    fields = [f.name for f in team.fields if f.name not in COLOR_FIELDS and f.name != "TGID"]
    slots = ujsn.decode(_region(dol, directory, "UJSN"))
    reg = _region(dol, directory, "PLCR")
    tb = _region(dol, directory, "PLCT")
    placed = placement.decode(reg, tb)
    decal_table = None
    if "DECL" in directory.entries:
        decal_table = _region(dol, directory, "DECL")
    rows = []
    for i in range(team.count):
        rec = team.record(template, i)
        tgid = rec["TGID"]
        row = {"TGID": tgid, "fields": {f: rec[f] for f in fields},
               "colors": read_colors(template, team, cpal, i),
               "jersey_slots": None, "captain_pgid": None, "placement": None}
        # The decal switch round-trips only when the base has the region; on an older base
        # the key is simply absent, which is what update.py's .get() already expects.
        if decal_table is not None:
            row["decals"] = {"team_logo": decals.logo_shown(decal_table, rec["TLGL"])}
        if tgid in NFL_TGIDS:
            key = ujsn.team_key(rec["TDNA"])
            if key not in slots:
                raise ValueError("team %r (TGID %d) has no row in the jersey table" % (rec["TDNA"], tgid))
            row["jersey_slots"] = slots[key]["slots"]
            row["captain_pgid"] = slots[key]["captain_pgid"]
            row["placement"] = placed[tgid]
        rows.append(row)
    return {"format_version": 1, "fields": fields, "rows": rows}


def dump(template, streamed, dol_bytes, directory, out_path, exported_by="dump_current"):
    roster_dbs(template, streamed)              # proves all three DBs are where they should be
    players = players_doc(template, dol_bytes, directory)
    teams = teams_doc(template, dol_bytes, directory)
    manifest = {
        "format": "rebornroster", "format_version": 1,
        "exported_at": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "exported_by": exported_by, "site": "reborn-builder dump " + VERSION, "snapshot_id": None,
        "requires_base": directory.contract_version, "base_label": directory.label,
        "counts": {"players": len(players["rows"]), "teams": len(teams["rows"]), "portraits": 0},
        "problems": [],
    }
    readme = ("Roster update dumped from the game files by Reborn Builder %s.\n"
              "%d players, %d teams, base %s.\n" % (VERSION, manifest["counts"]["players"],
                                                    manifest["counts"]["teams"], directory.label))
    write_rebornroster(str(out_path), manifest, players, teams, {}, readme)
    return manifest


def dump_from_root(root_dir, out_path, assume_legacy=False):
    r = Root(root_dir)
    template, streamed, dol_bytes = r.read("template.dat"), r.read("Streamed.db"), r.read_dol()
    return dump(template, streamed, dol_bytes, load_directory(Dol(dol_bytes), assume_legacy), out_path)


def dump_from_iso(iso_path, out_path, assume_legacy=False):
    iso = Iso(iso_path)
    dol_bytes = iso.read_dol()
    return dump(iso.read("template.dat"), iso.read("Streamed.db"), dol_bytes,
                load_directory(Dol(dol_bytes), assume_legacy), out_path)
