"""The Reborn data directory: where the data-layer regions live in this base.

    +0x00 'RBDD'   +0x04 u16 contract_version   +0x06 u16 entry_count
    +0x08 char[16] label (NUL padded)
    +0x18 entries x 16 B: char[4] tag, u8 file, u8 flags, u16 reserved, u32 address, u32 capacity
"""
import struct
from collections import namedtuple

MAGIC = b"RBDD"
FILE_DOL, FILE_TEMPLATE, FILE_STREAMED = 0, 1, 2

Entry = namedtuple("Entry", "tag file address capacity")

UJSN_MAGIC = b"UJSN"
PLACEMENT_CAVE, PLACEMENT_MARK = 0x80048120, 0x2804001F
LEGACY_FIXED = {
    "PLCR": (0x8004815C, 64),
    "PLCT": (0x8004819C, 64),
    "EYPG": (0x802C7880, 384),
    "EYLK": (0x802C7A7C, 96),
}


class Directory:
    def __init__(self, contract_version, label, entries):
        self.contract_version = contract_version
        self.label = label
        self.entries = dict(entries)

    def encode(self):
        out = bytearray(MAGIC)
        out += struct.pack(">HH", self.contract_version, len(self.entries))
        out += self.label.encode("ascii").ljust(16, b"\x00")[:16]
        for e in self.entries.values():
            out += struct.pack(">4sBBHII", e.tag.encode("ascii"), e.file, 0, 0, e.address, e.capacity)
        return bytes(out)

    @classmethod
    def parse(cls, dol):
        hits = dol.find(MAGIC)
        if not hits:
            return None
        if len(hits) > 1:
            raise ValueError("the DOL holds %d data directories; expected one" % len(hits))
        va = hits[0]
        try:
            head = dol.read(va, 0x18)
            if len(head) < 0x18:
                raise ValueError("data directory at 0x%x is truncated" % va)
            version, count = struct.unpack_from(">HH", head, 4)
            label = head[8:24].split(b"\x00")[0].decode("ascii", "replace")
            body = dol.read(va + 0x18, count * 16)
            if len(body) != count * 16:
                raise ValueError("data directory is truncated")
            entries = {}
            for i in range(count):
                tag, file, _flags, _res, addr, cap = struct.unpack_from(">4sBBHII", body, i * 16)
                tag = tag.decode("ascii", "replace")
                entries[tag] = Entry(tag, file, addr, cap)
            return cls(version, label, entries)
        except (LookupError, struct.error):
            raise ValueError("data directory at 0x%x is truncated" % va)

    @classmethod
    def legacy(cls, dol):
        # A base that already carries an RBDD directory (any base built by this plan)
        # always has one instance of the literal ASCII bytes b"UJSN" that is NOT a second
        # jersey-name table: the directory's own UJSN *entry* stores its tag that way. This
        # is only reached when the caller has decided to fall back to the legacy scan (or
        # calls it directly, as the unit tests below do), so it must be as self-consistent
        # against a modern DOL as it always was against a genuinely old one. Fix round 1,
        # 2026-08-28 -- the same self-reference reborn_base.release.preflight() hit the
        # moment it wrote a real directory next to a real table.
        rbdd_span = None
        try:
            existing = cls.parse(dol)
        except ValueError:
            existing = None
        if existing is not None:
            rbdd_hits = dol.find(MAGIC)
            if rbdd_hits:
                rbdd_span = (rbdd_hits[0], rbdd_hits[0] + 0x18 + len(existing.entries) * 16)

        def _is_genuine_table(o):
            # POSITIONAL: a hit inside an existing directory's own byte span is that
            # directory's entry tag, never a second table.
            if rbdd_span is not None and rbdd_span[0] <= o < rbdd_span[1]:
                return False
            # STRUCTURAL: a hit's header must also decode as a plausible v5 table (row 20,
            # 1..64 teams) to count as a table at all -- catches a genuine second table
            # anywhere else, and means a coincidental 4-byte match is never miscounted
            # either (in practice this alone already rejects the directory's own entry:
            # the bytes right after its "UJSN" tag are file/flags/address/capacity, not a
            # plausible version/team/row triple).
            try:
                hdr = dol.read(o, 24)
            except LookupError:
                return False
            if len(hdr) < 24:
                return False
            ver, nteam, row, pool, plen = struct.unpack_from(">5I", hdr, 4)
            return ver == 5 and 1 <= nteam <= 64 and row == 20

        hits = [o for o in dol.find(UJSN_MAGIC) if _is_genuine_table(o)]
        if len(hits) != 1:
            raise ValueError("expected one UJSN table in the DOL, found %d" % len(hits))
        try:
            mark = struct.unpack(">I", dol.read(PLACEMENT_CAVE, 4))[0]
        except (LookupError, struct.error):
            raise ValueError("this DOL has no placement cave")
        if mark != PLACEMENT_MARK:
            raise ValueError("placement caves are not installed in this DOL")
        hdr = dol.read(hits[0], 24)
        pool_off, pool_len = struct.unpack_from(">II", hdr, 16)
        entries = {"UJSN": Entry("UJSN", FILE_DOL, hits[0], pool_off + pool_len)}
        for tag, (addr, cap) in LEGACY_FIXED.items():
            entries[tag] = Entry(tag, FILE_DOL, addr, cap)
        return cls(0, "legacy", entries)
