"""Everything the window decides. No pywebview import lives here, so all of it is
testable with pytest and no window at all. gui.py is only a host for this object."""
import os
import struct
import threading
import time
import webbrowser

from . import VERSION, disc
from .cli import result_lines, write_log
from .directory import Directory
from .dol import Dol
from .dump_current import dump_from_iso, dump_from_root
from .errors import BuildError
from .gciso import Iso
from .locate import clean_tree, default_out, isos, textures_dir, today
from .pipeline import ROOT_STEPS, STEPS, Build, BuildRequest, steps_for
from .tdb import find_db
from .update import RosterUpdate, UpdateError

BASE_COMMAND = "py -3 tools/base_release.py --label YYYY.MM.DD --apply"
NO_DIRECTORY = "This disc has no Reborn data directory. Get the newer base ISO."
OUT_NOTE = "next to the original; the original is never touched"
ROOT_NOTE = "every ISO built from the clean tree carries this roster"
NO_ISO_CLOSING = "The roster is in the clean tree, but the playable ISO was not rebuilt."
BAD_ISO_CLOSING = "The ISO was rebuilt, but it did not read back as the clean tree."
NO_TEXTURES = "Reborn Dolphin not found; portraits will not be copied"
FOUND_NOTE = "found in Reborn Dolphin"
ALLOWED_URLS = ("https://developer.microsoft.com/microsoft-edge/webview2/",
                "https://nflstreetreborn.com/rdatabase/")


class NoDialogs:
    """The seam the window plugs its native file dialogs into. The default answers
    'canceled' to everything, which is exactly what a test wants."""

    def open_iso(self):
        return None

    def open_update(self):
        return None

    def save_iso(self, suggested):
        return None

    def open_folder(self):
        return None


def size_text(n):
    if n >= 1000000000:
        return "%.2f GB" % (n / 1000000000.0)
    return "%.1f MB" % (n / 1000000.0)


def dump_dir():
    """Where a hand-made dump lands. A seam, so a test never writes to Documents."""
    return os.path.join(os.path.expanduser("~"), "Documents")


def read_base(path):
    """One caption read straight off the disc. Measured at 4 ms on the shipping 1.36 GB
    ISO, so this is safe to do inside a synchronous call from the page."""
    card = {"path": path, "name": os.path.basename(path), "ok": False, "label": None,
            "contract_version": None, "players": None, "teams": None, "line": "", "problem": ""}
    try:
        iso = Iso(path)
        directory = Directory.parse(Dol(iso.read_dol()))
        if directory is None:
            card["problem"] = card["line"] = NO_DIRECTORY
            return card
        db = find_db(iso.read("template.dat"), {"PLAY", "TEAM", "CPAL"})
    except (OSError, LookupError, ValueError, struct.error) as e:
        card["problem"] = card["line"] = "Could not read this ISO: %s" % e
        return card
    card.update(ok=True, label=directory.label, contract_version=directory.contract_version,
                players=db.tables["PLAY"].count, teams=db.tables["TEAM"].count)
    card["line"] = "Base %s - %d players" % (card["label"], card["players"])
    return card


def read_update(path):
    card = {"path": path, "name": os.path.basename(path), "ok": False, "players": 0, "teams": 0,
            "portraits": 0, "requires_base": None, "base_label": "", "line": "",
            "warning_count": 0, "warnings": [], "problem": ""}
    try:
        upd = RosterUpdate.open(path)
    except UpdateError as e:
        card["problem"] = str(e)
        return card
    try:
        m = upd.manifest
        card.update(ok=True, players=len(upd.players), teams=len(upd.teams),
                    portraits=len(upd.texture_names), requires_base=m.requires_base,
                    base_label=m.base_label, warnings=m.problem_lines())
        card["warning_count"] = len(card["warnings"])
        card["line"] = "%d players - %d teams - %d portraits - needs base %s" % (
            card["players"], card["teams"], card["portraits"], card["base_label"])
    finally:
        upd.close()
    return card


def fit(base, update):
    """Does this file go with this disc? Compared numerically, never by label."""
    if not base or not update or not base["ok"] or not update["ok"]:
        return {"ok": None, "text": ""}
    if update["requires_base"] <= base["contract_version"]:
        return {"ok": True, "text": "This update fits this disc."}
    return {"ok": False,
            "text": "This update needs base %s (version %d); this disc is base %s (version %d)."
                    % (update["base_label"], update["requires_base"],
                       base["label"], base["contract_version"])}


class Api:
    """Every method here is reachable from the page as window.pywebview.api.<name>()."""

    def __init__(self, dialogs=None, opener=None, closer=None, update_path=None):
        self.dialogs = dialogs or NoDialogs()
        self.opener = opener or getattr(os, "startfile", lambda p: None)
        self.closer = closer or (lambda: None)
        self.base = None
        self.update = None
        self.out = ""
        self.textures = textures_dir()
        self.phase = "idle"
        self.result = None
        self.failure = None
        self._events = []
        self._lock = threading.Lock()
        self._starts = {}
        self._last_pct = -1
        self._log = []
        self._t0 = 0.0
        self._thread = None
        self._steps = list(STEPS)          # the step list of the run in progress (or the last one)
        found = isos()
        self.bases = [{"path": p, "name": os.path.basename(p), "note": FOUND_NOTE} for p in found]
        # On a PC with the clean tree, applying INTO it is the default: the roster then lives in
        # root/ and every ISO built from it carries the roster.  Building a separate ISO leaves
        # root/ untouched, which is how a roster gets stranded on one disc while other sessions
        # keep building the old one.  Players have no clean tree, so they still get ISO mode.
        self.target = "root" if clean_tree() else "iso"
        if found:
            self._set_base(found[0])
        if update_path:
            self._set_update(update_path)

    # ---- what is chosen
    def _set_base(self, path):
        self.base = read_base(path)
        self.out = default_out(path, today())
        if not any(b["path"] == path for b in self.bases):
            self.bases.insert(0, {"path": path, "name": os.path.basename(path), "note": ""})

    def _set_update(self, path):
        self.update = read_update(path)

    def choose_base(self, path):
        if self.phase != "building":
            self._set_base(path)
        return self.state()

    def browse_base(self):
        p = self.dialogs.open_iso()
        return self.choose_base(p) if p else self.state()

    def choose_update(self, path):
        if self.phase != "building":
            self._set_update(path)
        return self.state()

    def browse_update(self):
        p = self.dialogs.open_update()
        return self.choose_update(p) if p else self.state()

    def choose_out(self):
        p = self.dialogs.save_iso(self.out)
        if p:
            self.out = p
        return self.state()

    def choose_target(self, mode):
        """'root' = apply into the clean tree, 'iso' = write a separate dated ISO."""
        if self.phase != "building" and mode in ("root", "iso"):
            if mode == "root" and not self.advanced()["available"]:
                return self.state()
            self.target = mode
        return self.state()

    # ---- the gate, word for word what the Tk window said
    def _reason(self):
        if self.target == "root":
            if not self.advanced()["available"]:
                return "This PC has no clean tree"
            if not self.update or not self.update["ok"]:
                return "Pick a roster update"
            return ""
        if not self.base:
            return "Pick the game ISO"
        if not self.update or not self.update["ok"]:
            return "Pick a roster update"
        if not self.out:
            return "Pick where to write the new ISO"
        if os.path.abspath(self.out) == os.path.abspath(self.base["path"]):
            return "The new ISO must be a different file"
        if not self.base["ok"]:
            if self.base["problem"] == NO_DIRECTORY:
                return "This ISO has no Reborn data directory; get the newer base ISO"
            return "Could not read the ISO"
        if fit(self.base, self.update)["ok"] is False:
            return "This update needs base %s; your ISO is %s" % (self.update["base_label"],
                                                                  self.base["label"])
        return ""

    def gate(self):
        reason = self._reason()
        warned = bool(self.update and self.update["warning_count"])
        if self.target == "root":
            label = "Apply and build anyway" if warned else "Apply and build the ISO"
        else:
            label = "Build anyway" if warned else "Build"
        return {"ok": not reason, "reason": reason, "label": label}

    def advanced(self):
        root = clean_tree()
        if not root:
            return {"available": False}
        return {"available": True, "root": root, "base_command": BASE_COMMAND,
                "base_cwd": os.path.dirname(os.path.dirname(root))}

    @staticmethod
    def iso_name(root):
        """The disc a clean-tree build will rebuild, by the tree's own naming rule; empty
        when the tree has no tools folder to name it with."""
        tools = disc.tools_dir(root) if root else None
        return disc.canonical_iso_name(tools) if tools else ""

    # ---- advanced: only ever reachable on a PC that has the clean tree
    def advanced_apply(self):
        adv = self.advanced()
        if not adv["available"]:
            return {"started": False, "reason": "This PC has no clean tree."}
        if not self.update or not self.update["ok"]:
            return {"started": False, "reason": "Pick a roster update"}
        return self._start(BuildRequest(root=adv["root"], update=self.update["path"],
                                        textures_dir=self.textures))

    def advanced_dump(self, target):
        out = os.path.join(dump_dir(), "reborn-dump-%s.rebornroster" % today())
        try:
            if target == "root":
                adv = self.advanced()
                if not adv["available"]:
                    return {"ok": False, "path": "", "error": "This PC has no clean tree."}
                dump_from_root(adv["root"], out)
            elif target == "iso":
                if not self.base:
                    return {"ok": False, "path": "", "error": "Pick the game ISO"}
                dump_from_iso(self.base["path"], out)
            else:
                return {"ok": False, "path": "", "error": "Unknown dump target %r" % target}
        except (OSError, ValueError, LookupError, struct.error) as e:
            return {"ok": False, "path": "", "error": str(e)}
        return {"ok": True, "path": out, "error": ""}

    def state(self):
        adv = self.advanced()
        if self.phase == "idle":
            steps = list(ROOT_STEPS if self.target == "root" else STEPS)
        else:
            steps = list(self._steps)
        return {
            "version": VERSION,
            "steps": steps,
            "phase": self.phase,
            "bases": self.bases,
            "base": self.base,
            "update": self.update,
            "fit": fit(self.base, self.update),
            "out": {"path": self.out, "name": os.path.basename(self.out) if self.out else "",
                    "note": OUT_NOTE},
            "textures": {"path": self.textures,
                         "note": FOUND_NOTE if self.textures else NO_TEXTURES},
            "gate": self.gate(),
            "target": {"mode": self.target,
                       "root": (adv.get("root") or ""),
                       "iso": self.iso_name(adv.get("root")),
                       "switchable": adv["available"],
                       "note": ROOT_NOTE},
            "advanced": adv,
            "result": self.result,
            "failure": self.failure,
        }

    def close(self):
        self.closer()
        return {"closing": True}

    def open_url(self, url):
        if url not in ALLOWED_URLS:
            return {"ok": False}
        webbrowser.open(url)
        return {"ok": True}

    # ---- building
    def build(self):
        reason = self._reason()
        if reason:
            return {"started": False, "reason": reason}
        if self.target == "root":
            return self._start(BuildRequest(root=self.advanced()["root"], update=self.update["path"],
                                            textures_dir=self.textures))
        return self._start(BuildRequest(iso=self.base["path"], update=self.update["path"],
                                        out=self.out, textures_dir=self.textures))

    def _start(self, request):
        if self.phase == "building":
            return {"started": False, "reason": "A build is already running."}
        self.phase = "building"
        self.result = self.failure = None
        self._starts, self._last_pct, self._log = {}, -1, []
        self._steps = list(steps_for(request))
        with self._lock:
            self._events = []
        self._t0 = time.perf_counter()
        self._thread = threading.Thread(target=self._worker, args=(request,), daemon=True)
        self._thread.start()
        return {"started": True, "reason": ""}

    def _emit(self, event):
        with self._lock:
            self._events.append(event)

    def progress(self, since=0):
        """Monotonic, so a dropped poll heals itself on the next one."""
        with self._lock:
            events = self._events[since:]
        return {"next": since + len(events), "events": events}

    def _on_step(self, i, s):
        if s == "start":
            self._starts[i] = time.perf_counter()
            self._emit({"kind": "step", "index": i, "state": "start"})
        elif s == "done":
            began = self._starts.get(i, time.perf_counter())
            self._emit({"kind": "step", "index": i, "state": "done",
                        "seconds": round(time.perf_counter() - began, 1)})
        elif isinstance(s, tuple) and s and s[0] == "bytes":
            done, total = s[1], s[2]
            pct = 100 * done // max(1, total)
            if pct != self._last_pct:          # at most 101 events for a 1.4 GB copy
                self._last_pct = pct
                self._emit({"kind": "bytes", "index": i, "done": done, "total": total})

    def _worker(self, request):
        build = Build(request, progress=self._on_step)
        try:
            report = build.run()
        except BuildError as e:
            self._log = list(getattr(build, "log", []))        # Copy details then carries the tools' full output
            self._finish_failed(e)
            return
        except Exception as e:                 # a bug, not a refusal: still no half-written disc
            self._log = list(getattr(build, "log", []))
            self._finish_failed(BuildError("Build", "Something unexpected went wrong: %s" % e,
                                           repr(e)))
            return
        self._finish_done(report)

    def _finish_done(self, report):
        seconds = time.perf_counter() - self._t0
        lines = result_lines(report)
        lines[0] = "Done   %d:%02d" % divmod(int(seconds), 60)
        notes = [report.portrait_error] if report.portrait_error else []
        log_path = ""
        try:
            log_path = write_log(report, lines)
        except OSError as e:
            notes.append("Could not write build-log.txt: %s" % (e.strerror or e))
        # The card names the thing to play: the rebuilt ISO after a clean-tree build, the
        # new ISO after an ISO build, and only the tree itself when the disc was skipped.
        if report.is_root and report.iso:
            shown = report.iso
        else:
            shown = os.path.abspath(report.out)
        try:
            size = 0 if (report.is_root and not report.iso) else os.path.getsize(shown)
        except OSError:
            size = 0
        self.result = {
            "name": shown if (report.is_root and not report.iso) else os.path.basename(shown),
            "path": shown,
            "folder": shown if (report.is_root and not report.iso) else os.path.dirname(shown),
            "root": os.path.abspath(report.out) if report.is_root else "",
            "size": size, "size_text": size_text(size) if size else "",
            "sha256": report.sha256, "short_sha": report.sha256[:8],
            "seconds": round(seconds, 1), "counts": report.counts,
            "base_label": report.base_label, "warnings": list(report.warnings),
            "notes": notes, "log_path": log_path, "is_root": report.is_root,
        }
        self._log = list(report.log)
        self.phase = "done"
        self._emit({"kind": "done", "result": self.result})

    def _finish_failed(self, err):
        if err.step == "Build":
            closing = "The build did not finish."
        elif err.step in disc.DISC_STEPS[:3]:
            closing = NO_ISO_CLOSING
        elif err.step == disc.DISC_STEPS[3]:
            closing = BAD_ISO_CLOSING
        elif err.step in (STEPS[4], STEPS[5]):
            closing = "The unfinished ISO was deleted."
        else:
            closing = "Nothing was written."
        self.failure = {"step": err.step,
                        "step_index": self._steps.index(err.step) if err.step in self._steps else -1,
                        "sentence": err.sentence, "closing": closing, "details": err.details}
        self.phase = "failed"
        self._emit({"kind": "failed", "failure": self.failure})

    def reset(self):
        if self.phase == "building":
            return self.state()
        self.phase = "idle"
        self.result = self.failure = None
        self._log = []
        with self._lock:
            self._events = []
        if self.base:
            self.out = default_out(self.base["path"], today())
        return self.state()

    def show_in_folder(self):
        if not self.result:
            return {"ok": False, "error": "There is nothing to show yet."}
        try:
            self.opener(self.result["folder"])
        except OSError as e:
            return {"ok": False, "error": str(e)}
        return {"ok": True, "error": ""}

    def details_text(self):
        parts = []
        if self.failure:
            parts += ["Stopped at %s" % self.failure["step"], self.failure["sentence"],
                      self.failure["closing"]]
            if self.failure["details"]:
                parts.append(self.failure["details"])
        parts += self._log
        return {"text": "\n".join(parts) if parts else "There is nothing to copy yet."}
