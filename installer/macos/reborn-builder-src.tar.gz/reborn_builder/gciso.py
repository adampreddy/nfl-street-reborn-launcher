"""GameCube disc image: boot header fields, FST, in-place range patching."""
import hashlib
import os
import struct

CHUNK = 4 * 1024 * 1024


class Iso:
    def __init__(self, path):
        self.path = str(path)
        with open(self.path, "rb") as f:
            f.seek(0x420)
            self.dol_off, self.fst_off, self.fst_size = struct.unpack(">III", f.read(12))
            f.seek(self.dol_off)
            dh = f.read(0x100)
            self.dol_len = max(
                max(struct.unpack_from(">I", dh, i * 4)[0] + struct.unpack_from(">I", dh, 0x90 + i * 4)[0] for i in range(7)),
                max(struct.unpack_from(">I", dh, 0x1C + i * 4)[0] + struct.unpack_from(">I", dh, 0xAC + i * 4)[0] for i in range(11)))
            f.seek(self.fst_off)
            fst = f.read(self.fst_size)
        n = struct.unpack_from(">I", fst, 8)[0]
        strings = fst[n * 12:]
        self.files = {}
        stack, i = [(n, "")], 1
        while i < n:
            flags = fst[i * 12]
            name_off = struct.unpack_from(">I", fst, i * 12)[0] & 0xFFFFFF
            a, b = struct.unpack_from(">II", fst, i * 12 + 4)
            name = strings[name_off:strings.find(b"\x00", name_off)].decode("latin1")
            while len(stack) > 1 and i >= stack[-1][0]:
                stack.pop()
            path = (stack[-1][1] + "/" + name).lstrip("/")
            if flags:
                stack.append((b, path))
            else:
                self.files[path] = (a, b)
            i += 1

    def extent(self, name):
        if name not in self.files:
            raise LookupError("the ISO has no file named %s" % name)
        return self.files[name]

    def read(self, name):
        off, ln = self.extent(name)
        with open(self.path, "rb") as f:
            f.seek(off)
            return f.read(ln)

    def read_dol(self):
        with open(self.path, "rb") as f:
            f.seek(self.dol_off)
            return f.read(self.dol_len)


def _check_ranges(writes, total):
    spans = sorted((off, off + len(data)) for off, data in writes.items())
    last = 0
    for a, b in spans:
        if a < last:
            raise ValueError("write ranges overlap at 0x%x" % a)
        if b > total:
            raise ValueError("write range 0x%x..0x%x runs past the end of the file (0x%x)" % (a, b, total))
        last = b


def patch_copy(src, dst, writes, progress=None):
    total = os.path.getsize(src)
    _check_ranges(writes, total)
    part = dst + ".part"
    h = hashlib.sha256()
    try:
        with open(src, "rb") as fi, open(part, "wb") as fo:
            pos = 0
            while True:
                buf = fi.read(CHUNK)
                if not buf:
                    break
                buf = bytearray(buf)
                end = pos + len(buf)
                for off, data in writes.items():
                    a, b = max(off, pos), min(off + len(data), end)
                    if a < b:
                        buf[a - pos:b - pos] = data[a - off:b - off]
                fo.write(buf)
                h.update(buf)
                pos = end
                if progress:
                    progress(pos, total)
        os.replace(part, dst)
    except BaseException:
        if os.path.exists(part):
            os.remove(part)
        raise
    return h.hexdigest()


def verify_ranges(path, writes):
    bad = []
    with open(path, "rb") as f:
        for off in sorted(writes):
            f.seek(off)
            if f.read(len(writes[off])) != writes[off]:
                bad.append(off)
    return bad
