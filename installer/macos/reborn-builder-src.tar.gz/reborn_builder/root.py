"""The clean tree's game files: a folder holding template.dat, Streamed.db and
&&systemdata/Start.dol -- the same three things Iso reads out of a disc image, read
the same way (read(name) / read_dol()) so pipeline.py can compose against either one.

Writing is whole-file, never partial: each file is backed up before the first byte of
it is touched, then replaced through a .part file so an interrupted run cannot leave a
half-written template.dat. The tree's own files are never deleted; on a verification
failure the caller restores them from the backups made here.
"""
import hashlib
import os
import shutil
import time

TEMPLATE_NAME = "template.dat"
STREAMED_NAME = "Streamed.db"
DOL_REL = os.path.join("&&systemdata", "Start.dol")


class Root:
    def __init__(self, path):
        self.path = str(path)
        self.template_path = os.path.join(self.path, TEMPLATE_NAME)
        self.streamed_path = os.path.join(self.path, STREAMED_NAME)
        self.dol_path = os.path.join(self.path, DOL_REL)

    def read(self, name):
        if name == TEMPLATE_NAME:
            path = self.template_path
        elif name == STREAMED_NAME:
            path = self.streamed_path
        else:
            raise LookupError("the root folder has no file named %s" % name)
        with open(path, "rb") as f:
            return f.read()

    def read_dol(self):
        with open(self.dol_path, "rb") as f:
            return f.read()


def _restore_one(path, backup):
    part = path + ".part"
    with open(backup, "rb") as f:
        data = f.read()
    with open(part, "wb") as f:
        f.write(data)
    os.replace(part, path)


def write_root(root_dir, tbuf, sbuf, dbuf, progress=None):
    """Back up, then atomically overwrite, the three whole files. Returns (sha256,
    backups); backups maps each written path to the backup made of it (only for paths
    that already existed) so restore_root() can put things back if verification fails.
    If a write fails partway through, whatever this call already replaced is restored
    from those same backups before the error is re-raised."""
    r = Root(root_dir)
    targets = [(r.template_path, bytes(tbuf)), (r.streamed_path, bytes(sbuf)), (r.dol_path, bytes(dbuf))]
    ts = time.strftime("%Y%m%d-%H%M%S")
    backups = {}
    for path, _ in targets:
        if os.path.exists(path):
            bak = path + ".bak_pre_roster_" + ts
            shutil.copy2(path, bak)
            backups[path] = bak
    total = sum(len(data) for _, data in targets)
    done = 0
    h = hashlib.sha256()
    written = []
    try:
        for path, data in targets:
            part = path + ".part"
            with open(part, "wb") as f:
                f.write(data)
            os.replace(part, path)
            written.append(path)
            h.update(data)
            done += len(data)
            if progress:
                progress(done, total)
    except OSError:
        for path in written:
            if path in backups:
                _restore_one(path, backups[path])
        raise
    return h.hexdigest(), backups


def restore_root(backups):
    """Put the three files back the way they were before write_root() touched them."""
    for path, bak in backups.items():
        _restore_one(path, bak)


def verify_root(root_dir, tbuf, sbuf, dbuf):
    """Read the three files back from disk; return the names that don't match byte for
    byte what should be there (empty means everything verified)."""
    r = Root(root_dir)
    checks = [(TEMPLATE_NAME, r.template_path, bytes(tbuf)), (STREAMED_NAME, r.streamed_path, bytes(sbuf)),
              ("Start.dol", r.dol_path, bytes(dbuf))]
    bad = []
    for name, path, want in checks:
        try:
            with open(path, "rb") as f:
                got = f.read()
        except OSError:
            bad.append(name)
            continue
        if got != want:
            bad.append(name)
    return bad
