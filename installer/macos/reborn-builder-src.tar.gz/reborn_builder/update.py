"""The .rebornroster file: a deterministic zip of manifest, players, teams, portraits."""
import hashlib
import json
import zipfile
from collections import namedtuple
from dataclasses import dataclass, field

from . import SUPPORTED_FORMAT_VERSIONS
from . import decals

FORMAT = "rebornroster"
FIXED_TIME = (2000, 1, 1, 0, 0, 0)
UNHASHED = ("manifest.json", "README.txt")


class UpdateError(Exception):
    pass


@dataclass
class Manifest:
    format: str
    format_version: int
    exported_at: str
    exported_by: str
    site: str
    snapshot_id: object
    requires_base: int
    base_label: str
    counts: dict = field(default_factory=dict)
    members: dict = field(default_factory=dict)
    problems: list = field(default_factory=list)

    def problem_lines(self):
        return [p.get("text", str(p)) if isinstance(p, dict) else str(p) for p in self.problems]


# `decals` defaults to None so every existing caller that builds a TeamRow positionally
# with six fields keeps working, and "no switch in this update" stays the default.
TeamRow = namedtuple("TeamRow", "tgid fields colors jersey_slots captain_pgid placement decals",
                     defaults=(None,))


def sha256_hex(data):
    return hashlib.sha256(data).hexdigest()


def _dump(doc):
    return (json.dumps(doc, indent=1, sort_keys=True, ensure_ascii=False) + "\n").encode("utf-8")


def write_rebornroster(path, manifest, players, teams, textures, readme, extras=None):
    """extras: further hashed members, {name: bytes}, for example history.json."""
    members = [("players.json", _dump(players)), ("teams.json", _dump(teams))]
    members += sorted(textures.items())
    members += sorted((extras or {}).items())
    manifest = dict(manifest)
    manifest["members"] = {name: "sha256:" + sha256_hex(data) for name, data in members}
    ordered = [("manifest.json", _dump(manifest))] + members + [("README.txt", readme.encode("utf-8"))]
    with zipfile.ZipFile(path, "w") as z:
        for name, data in ordered:
            info = zipfile.ZipInfo(name, date_time=FIXED_TIME)
            info.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(info, data)


class RosterUpdate:
    def __init__(self, path, manifest, players_doc, teams_doc, texture_names, zf):
        self.path = str(path)
        self.manifest = manifest
        self.player_fields = list(players_doc["fields"])
        self.players = list(players_doc["rows"])
        self.team_fields = list(teams_doc["fields"])
        # `decals` is OPTIONAL and read with .get, so a file written before it existed still
        # loads and an older builder ignores a file that has it. No format_version bump.
        self.teams = [TeamRow(int(r["TGID"]), dict(r["fields"]), r.get("colors"), r.get("jersey_slots"),
                              r.get("captain_pgid"), r.get("placement"), decals.parse(r.get("decals")))
                      for r in teams_doc["rows"]]
        self.texture_names = texture_names
        self._zf = zf

    @classmethod
    def open(cls, path):
        try:
            zf = zipfile.ZipFile(path)
        except (zipfile.BadZipFile, OSError) as e:
            raise UpdateError("%s is not a roster update file (%s)" % (path, e))
        try:
            return cls._load(path, zf)
        except BaseException:
            zf.close()
            raise

    @classmethod
    def _load(cls, path, zf):
        bad = zf.testzip()
        if bad:
            raise UpdateError("the update file is damaged (%s did not read back)" % bad)
        names = zf.namelist()
        try:
            manifest = Manifest(**json.loads(zf.read("manifest.json")))
        except (KeyError, TypeError, ValueError) as e:
            raise UpdateError("the update file has no readable manifest (%s)" % e)
        if manifest.format != FORMAT:
            raise UpdateError("this is not a roster update (format %r)" % manifest.format)
        if manifest.format_version not in SUPPORTED_FORMAT_VERSIONS:
            raise UpdateError("this update was made by a newer site (format %d); update Reborn Builder"
                              % manifest.format_version)
        for name in names:
            if name in UNHASHED or name.endswith("/"):
                continue
            want = manifest.members.get(name)
            if not want:
                raise UpdateError("%s is in the file but not in the manifest" % name)
            got = "sha256:" + sha256_hex(zf.read(name))
            if got != want:
                raise UpdateError("%s does not match its checksum; the file was changed after export" % name)
        for name in manifest.members:
            if name not in names:
                raise UpdateError("%s is listed in the manifest but missing from the file" % name)
        try:
            players = json.loads(zf.read("players.json"))
            teams = json.loads(zf.read("teams.json"))
            if not isinstance(players.get("fields"), list) or not isinstance(teams.get("fields"), list):
                raise ValueError("fields must be a list")
            for r in players["rows"]:
                int(r["PGID"])
            for r in teams["rows"]:
                int(r["TGID"])
                if not isinstance(r.get("fields"), dict):
                    raise ValueError("team %s has no fields" % r.get("TGID"))
        except (KeyError, TypeError, ValueError, AttributeError) as e:
            raise UpdateError("players.json or teams.json is not in the expected shape (%s)" % e)
        textures = sorted(n for n in names if n.startswith("textures/") and not n.endswith("/"))
        for name in textures:
            parts = name.split("/")
            if (len(parts) < 3 or any(p in ("", ".", "..") for p in parts) or "\\" in name
                    or any(":" in p for p in parts)):
                raise UpdateError("the update contains a portrait with an unsafe name: %s" % name)
        return cls(path, manifest, players, teams, textures, zf)

    def close(self):
        self._zf.close()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False

    def read_texture(self, name):
        return self._zf.read(name)

    HISTORY = "history.json"

    def history(self):
        """The gear history the site packed, parsed, or None for an export made before it existed."""
        if self.HISTORY not in self._zf.namelist():
            return None
        try:
            doc = json.loads(self._zf.read(self.HISTORY))
        except ValueError as e:
            raise UpdateError("%s is not readable (%s)" % (self.HISTORY, e))
        if not isinstance(doc, dict):
            raise UpdateError("%s is not an object" % self.HISTORY)
        return doc
