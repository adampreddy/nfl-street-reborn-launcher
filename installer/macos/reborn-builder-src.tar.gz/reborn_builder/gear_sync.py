"""The merge itself: pure functions over plain dicts. Nothing here reads a file.

A row is a list of 24 ints in GEAR_FIELDS order. A roster is {pgid: (person, row)}. The
person rule is the site's own: the trimmed full name, "" for a vacant slot. A card's stamp
is a naive local wall-clock datetime; history times are UTC and are brought to local wall
clock here, never the other way round.
"""
from datetime import datetime, timedelta

from .writers.roster import GEAR_FIELDS

PGID = GEAR_FIELDS.index("PGID")
TGID = GEAR_FIELDS.index("TGID")
IDENTITY = (PGID, TGID)
GEAR = [i for i in range(len(GEAR_FIELDS)) if i not in IDENTITY]
MARGIN = timedelta(hours=2)
STATE_FORMAT = 1
HISTORY_FORMAT = 1


def person(row):
    if row.get("vacant"):
        return ""
    return ("%s %s" % (str(row.get("PFNA") or "").strip(), str(row.get("PLNA") or "").strip())).strip()


def gear_of(row):
    return [int(row[c]) for c in GEAR_FIELDS]


def roster_view(players):
    """players.json rows -> {pgid: (person, row)}."""
    return {int(r["PGID"]): (person(r), gear_of(r)) for r in players}


def same_gear(a, b):
    return all(a[i] == b[i] for i in GEAR)


def local_wall(iso_utc):
    """'2026-08-29T02:16:10Z' -> the naive local wall clock on this machine."""
    return datetime.fromisoformat(iso_utc.replace("Z", "+00:00")).astimezone().replace(tzinfo=None)


def check_history(h):
    if not isinstance(h, dict) or h.get("format") != HISTORY_FORMAT:
        raise ValueError("history.json: unknown format %r" % (h.get("format") if isinstance(h, dict) else h))
    if list(h.get("gear_cols", [])) != GEAR_FIELDS:
        raise ValueError("history.json: gear columns differ from this builder's")
    for key in ("floor", "changes"):
        if key not in h:
            raise ValueError("history.json: no %s" % key)
    floor = h["floor"]
    if not isinstance(floor, dict) or not isinstance(floor.get("rows"), dict):
        raise ValueError("history.json: floor.rows is not an object")
    for k, v in floor["rows"].items():
        _check_state("history.json: floor row %s" % k, k, v)
    if not isinstance(h["changes"], dict):
        raise ValueError("history.json: changes is not an object")
    for k, entries in h["changes"].items():
        if not isinstance(entries, list):
            raise ValueError("history.json: changes for %s is not a list" % k)
        for e in entries:
            _check_state("history.json: change for %s" % k, k, e)
            t = e.get("time") if isinstance(e, dict) else None
            if not isinstance(t, str) or not (t.endswith("Z") or t[-6] in "+-"):
                raise ValueError("history.json: change for %s has no UTC time" % k)
            local_wall(t)
    return h


def _check_state(where, pgid, v):
    try:
        int(pgid)
    except (TypeError, ValueError):
        raise ValueError("%s: PGID is not a number" % where)
    if not isinstance(v, dict) or not isinstance(v.get("person"), str):
        raise ValueError("%s: no person" % where)
    gear = v.get("gear")
    if not isinstance(gear, list) or len(gear) != len(GEAR_FIELDS) or not all(isinstance(x, int) for x in gear):
        raise ValueError("%s: gear is not %d integers" % (where, len(GEAR_FIELDS)))


def state_at(history, tau):
    """{pgid: (person, row)} as the roster stood at local wall-clock time tau; None means the floor."""
    out = {int(k): (str(v["person"]), [int(x) for x in v["gear"]]) for k, v in history["floor"]["rows"].items()}
    if tau is None:
        return out
    for k, entries in history["changes"].items():
        for e in entries:
            if local_wall(e["time"]) <= tau:
                out[int(k)] = (str(e["person"]), [int(x) for x in e["gear"]])
            else:
                break
    return out


def eras(history, stamp):
    """The floor, then every export time at or before stamp - MARGIN, oldest first."""
    cutoff = stamp - MARGIN
    times = {local_wall(e["time"]) for entries in history["changes"].values() for e in entries}
    return [None] + sorted(t for t in times if t <= cutoff)


def base_at(history, stamp, card_rows=None):
    """The roster a profile's gear was seeded from.

    A profile's gear rows are copied from the disc when the profile is CREATED and never
    re-seeded, so the save stamp is only an upper bound on the era. The era is inferred from
    the card itself: of the floor and every export at or before stamp - MARGIN, the one whose
    gear matches the most card rows wins, ties to the older era (the spec's direction for
    doubt). Without card rows the newest eligible era is returned.
    """
    candidates = eras(history, stamp)
    if card_rows is None:
        return state_at(history, candidates[-1])
    best, best_score = None, -1
    for tau in candidates:
        st = state_at(history, tau)
        score = sum(1 for pgid, row in card_rows.items() if pgid in st and same_gear(row, st[pgid][1]))
        if score > best_score:
            best, best_score = st, score
    return best


class Profile:
    """One profile's record in the state file: what was last written, who sat where, and
    the member's edits. overlay is {person: {from_pgid: row}}: keyed by the person and by
    the slot the edit was made in, so two same-named people never share an entry."""
    __slots__ = ("base", "persons", "overlay", "roster_sha", "written_at")

    def __init__(self, base=None, persons=None, overlay=None, roster_sha="", written_at=""):
        self.base = {k: list(v) for k, v in (base or {}).items()}
        self.persons = dict(persons or {})
        self.overlay = {who: {int(p): list(g) for p, g in entries.items()}
                        for who, entries in (overlay or {}).items()}
        self.roster_sha = roster_sha
        self.written_at = written_at

    @classmethod
    def from_json(cls, d):
        return cls({int(k): [int(x) for x in v] for k, v in d.get("base", {}).items()},
                   {int(k): str(v) for k, v in d.get("persons", {}).items()},
                   {str(who): {int(p): [int(x) for x in g] for p, g in entries.items()}
                    for who, entries in d.get("overlay", {}).items()},
                   str(d.get("roster_sha", "")), str(d.get("written_at", "")))

    def to_json(self):
        return {"base": {str(k): self.base[k] for k in sorted(self.base)},
                "persons": {str(k): self.persons[k] for k in sorted(self.persons)},
                "overlay": {who: {str(p): self.overlay[who][p] for p in sorted(self.overlay[who])}
                            for who in sorted(self.overlay)},
                "roster_sha": self.roster_sha, "written_at": self.written_at}


class Report:
    __slots__ = ("bootstrap", "updated", "harvested", "carried", "skipped")

    def __init__(self):
        self.bootstrap, self.updated, self.harvested, self.carried, self.skipped = False, 0, 0, 0, 0


def sync_profile(card_rows, roster, history, state, stamp, harvest_only=False):
    """Decide what a profile's gear rows should become.

    card_rows: {pgid: row} read from the card. roster: roster_view(). history: parsed
    history.json or None. state: the Profile last written for this save, or None. stamp:
    the save's local wall clock. Returns (writes {pgid: row}, new Profile, Report).
    """
    rep = Report()
    # The member's edits survive a bootstrap: a state with an empty base still holds them.
    overlay = ({who: {p: list(g) for p, g in entries.items()} for who, entries in state.overlay.items()}
               if state is not None else {})
    if state is None or not state.base:
        if history is None:
            raise LookupError("no record of this profile and the roster update carries no history")
        b = base_at(history, stamp, card_rows)
        base = {p: row for p, (_, row) in b.items()}
        persons = {p: who for p, (who, _) in b.items()}
        rep.bootstrap = True
    else:
        base, persons = state.base, state.persons

    # A row the base never knew is not the launcher's to touch: it is left alone and counted.
    unbased = {pgid for pgid in card_rows if pgid not in base}

    # Harvest: every row that differs from what was last written is the member's, filed
    # under the person and the slot it was made in, so two same-named people never share.
    for pgid, row in card_rows.items():
        if pgid in unbased:
            continue
        was = base[pgid]
        if same_gear(row, was):
            continue
        who = persons.get(pgid, "")
        # A slot vacant at the base has nobody to credit; whoever the roster puts there is new and takes the roster's gear.
        if who:
            overlay.setdefault(who, {})[pgid] = list(row)
            rep.harvested += 1

    def person_at(pgid):
        return roster[pgid][0] if pgid in roster else ""

    # Apply: the roster's gear for the person now in the slot, or the member's version of it.
    writes = {}
    if not harvest_only:
        for pgid, row in card_rows.items():
            r = roster.get(pgid)
            if r is None or pgid in unbased:
                rep.skipped += 1
                continue
            who, gear = r
            entries = overlay.get(who, {}) if who else {}
            if pgid in entries:
                target = list(entries[pgid])
            else:
                # An entry whose origin slot no longer holds this person followed them here.
                # Two such entries (two same-named people moved at once) cannot be told apart,
                # so neither is applied.
                moved = [p for p in entries if person_at(p) != who]
                if len(moved) == 1:
                    target = entries.pop(moved[0])
                    entries[pgid] = target
                    target = list(target)
                    rep.carried += 1
                else:
                    target = list(gear)
            target[PGID] = pgid
            target[TGID] = gear[TGID]
            if target != list(row):
                writes[pgid] = target
        rep.updated = len(writes)

    new_rows = dict(card_rows)
    new_rows.update(writes)
    new_persons = {}
    for pgid in new_rows:
        if not harvest_only and pgid in roster:
            new_persons[pgid] = roster[pgid][0]
        else:
            new_persons[pgid] = persons.get(pgid, "")
    return writes, Profile(new_rows, new_persons, overlay), rep
