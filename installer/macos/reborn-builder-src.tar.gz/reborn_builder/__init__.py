"""Reborn Builder: apply a .rebornroster to an NFL Street 2 Reborn ISO."""
VERSION = "0.1.1"
SUPPORTED_FORMAT_VERSIONS = (1,)
