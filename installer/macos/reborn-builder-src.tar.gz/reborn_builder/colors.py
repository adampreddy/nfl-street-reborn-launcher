"""Team colors: hex in, a 4-shade CPAL ramp out. Port of tools/team_colors.py.

CPAL record = 16 bytes: red for H,M,P,S at b0..b3; blue for H,M at b4,b5 and
for P,S at b10,b11; green for H,M,P,S at b6..b9; b12 = row index << 1.
The renderer keeps 5 bits per channel, so every shade sits on an 8-step grid.
"""

GRID = 8
SHADES = ("H", "M", "P", "S")
CPAL_BYTE = {
    ("H", "r"): 0, ("M", "r"): 1, ("P", "r"): 2, ("S", "r"): 3,
    ("H", "b"): 4, ("M", "b"): 5, ("P", "b"): 10, ("S", "b"): 11,
    ("H", "g"): 6, ("M", "g"): 7, ("P", "g"): 8, ("S", "g"): 9,
}
CPAL_ID_BYTE = 12


def r16(v):
    return max(0, min(256 - GRID, int(round(v / float(GRID))) * GRID))


def f16(v):
    return max(0, min(256 - GRID, (int(v) // GRID) * GRID))


def parse_hex(s):
    if not isinstance(s, str):
        raise ValueError("bad color %r (want #RRGGBB)" % (s,))
    s = s.strip()
    if s.startswith("#"):
        s = s[1:]
    elif s[:2].lower() == "0x":
        s = s[2:]
    if len(s) == 3:
        s = "".join(c * 2 for c in s)
    if len(s) != 6:
        raise ValueError("bad color %r (want #RRGGBB)" % s)
    return (int(s[0:2], 16), int(s[2:4], 16), int(s[4:6], 16))


def to_hex(rgb):
    return "#%02X%02X%02X" % tuple(rgb)


def derive_ramp(p):
    return {"M": tuple(r16(c - 4) for c in p),
            "P": tuple(r16(c + 4) for c in p),
            "S": tuple(f16(c * 0.62) for c in p),
            "H": tuple(max(GRID, r16(c * 1.30)) for c in p)}


def desired_ramp(hex_str, shades):
    ramp = derive_ramp(parse_hex(hex_str))
    for sh in SHADES:
        if shades and shades.get(sh) is not None:
            ramp[sh] = parse_hex(shades[sh])
    return ramp


def ramp_from_slot(row16):
    return {sh: tuple(row16[CPAL_BYTE[(sh, ch)]] for ch in "rgb") for sh in SHADES}


def slot_bytes(ramp, index):
    out = bytearray(16)
    for sh in SHADES:
        for k, ch in enumerate("rgb"):
            out[CPAL_BYTE[(sh, ch)]] = max(0, min(255, int(ramp[sh][k])))
    out[CPAL_ID_BYTE] = (index << 1) & 0xFF
    return bytes(out)


def ramp_colors(ramp):
    return tuple(slot_bytes(ramp, 0)[:12])


def export_shades(ramp, hex_str):
    base = derive_ramp(parse_hex(hex_str))
    return {sh: (None if tuple(ramp[sh]) == base[sh] else to_hex(ramp[sh])) for sh in SHADES}
