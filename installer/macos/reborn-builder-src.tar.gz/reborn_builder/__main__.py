import sys

args = sys.argv[1:]
if len(args) == 1 and args[0].lower().endswith(".rebornroster"):
    from reborn_builder.gui import run
    sys.exit(run(args[0]))
elif args:
    from reborn_builder.cli import main
    sys.exit(main())
else:
    from reborn_builder.gui import run
    sys.exit(run())
