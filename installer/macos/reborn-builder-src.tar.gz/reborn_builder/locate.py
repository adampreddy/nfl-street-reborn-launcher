"""Where Reborn Dolphin keeps things on this PC."""
import datetime
import glob
import os
import sys


def reborn_root():
    root = os.path.join(os.environ.get("APPDATA", ""), "NFL Street Reborn")
    return root if os.path.isdir(root) else None


def games_dir():
    root = reborn_root()
    d = os.path.join(root, "Games") if root else None
    return d if d and os.path.isdir(d) else None


def textures_dir():
    root = reborn_root()
    d = os.path.join(root, "User", "Load", "Textures") if root else None
    return d if d and os.path.isdir(d) else None


def isos():
    d = games_dir()
    if not d:
        return []
    paths = glob.glob(os.path.join(d, "*.iso"))
    return sorted(paths, key=lambda p: os.path.getmtime(p), reverse=True)


def today():
    return datetime.date.today().isoformat()


def default_out(iso_path, day):
    folder, name = os.path.split(iso_path)
    stem = os.path.splitext(name)[0]
    cand = os.path.join(folder, "%s [%s].iso" % (stem, day))
    n = 2
    while os.path.exists(cand):
        cand = os.path.join(folder, "%s [%s]-%d.iso" % (stem, day, n))
        n += 1
    return cand


CLEAN_TREE_ENV = "REBORN_CLEAN_TREE"
CLEAN_TREE_POINTER = "clean-tree.txt"
WEBVIEW2_CLIENT = "{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}"


def _clean_tree_candidates():
    yield os.environ.get(CLEAN_TREE_ENV)
    if not getattr(sys, "frozen", False):
        # <clean>/tools/reborn_builder/reborn_builder/locate.py -> <clean>
        here = os.path.dirname(os.path.abspath(__file__))
        clean = os.path.dirname(os.path.dirname(os.path.dirname(here)))
        yield os.path.join(clean, "GameCube Version", "root")
    root = reborn_root()
    if root:
        try:
            # utf-8-sig: PowerShell's `Out-File -Encoding utf8` (build_exe.ps1) writes a
            # BOM. Plain utf-8 would leave it on the front of the path, so the very next
            # os.path.isfile check misses by one invisible character every time.
            with open(os.path.join(root, "Tools", CLEAN_TREE_POINTER), encoding="utf-8-sig") as f:
                yield f.readline().strip()
        except OSError:
            pass


def clean_tree():
    """The clean tree's root folder on this PC, or None. A folder counts only when it
    actually holds template.dat, so a pointer file copied to somebody else's PC just
    fails and the Advanced section never appears there."""
    for cand in _clean_tree_candidates():
        if cand and os.path.isfile(os.path.join(cand, "template.dat")):
            return os.path.abspath(cand)
    return None


def webview2_version(reader=None):
    """The installed Edge WebView2 Runtime version, or None. `reader(hive, path, value)`
    is the seam the tests use; it returns a string or raises OSError. Mirrors pywebview's
    own _is_chromium() probe."""
    if sys.platform != "win32" and reader is None:
        return "n/a"
    if reader is None:
        import winreg

        def reader(hive, path, value):
            with winreg.OpenKey(getattr(winreg, hive), path) as key:
                return str(winreg.QueryValueEx(key, value)[0])
    clients = "Microsoft\\EdgeUpdate\\Clients\\" + WEBVIEW2_CLIENT
    places = [("HKEY_LOCAL_MACHINE", "SOFTWARE\\WOW6432Node\\" + clients),
              ("HKEY_LOCAL_MACHINE", "SOFTWARE\\" + clients),
              ("HKEY_CURRENT_USER", "SOFTWARE\\" + clients)]
    for hive, path in places:
        try:
            pv = reader(hive, path, "pv")
        except OSError:
            continue
        if pv:
            return pv
    return None
