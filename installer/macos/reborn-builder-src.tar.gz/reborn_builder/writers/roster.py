"""PLAY and PRGR writers: rows matched by PGID, only listed fields written."""

GEAR_FIELDS = ["PSPA", "PHDC", "PSOC", "PTBD", "PMED", "PTFD", "PRHD", "PGID",
               "TGID", "PHND", "PLUL", "PLWL", "PHTM", "PSTM", "PSHO", "PUAR",
               "PHOR", "PEWR", "PHAT", "PJCT", "PPNT", "PSRT", "PWRT", "PEBW"]


class KeyMismatch(ValueError):
    def __init__(self, table, key, missing_in_iso, missing_in_update):
        self.table, self.key = table, key
        self.missing_in_iso = sorted(missing_in_iso)
        self.missing_in_update = sorted(missing_in_update)
        super().__init__("%s: %d %s value(s) not in the ISO, %d not in the update"
                         % (table, len(self.missing_in_iso), key, len(self.missing_in_update)))


def check_keys(table, buf, rows, key):
    index = table.index(buf, key)
    wanted = [int(r[key]) for r in rows]
    if len(set(wanted)) != len(wanted):
        dup = sorted({k for k in wanted if wanted.count(k) > 1})
        raise ValueError("%s: the update repeats %s %s" % (table.name, key, dup))
    a, b = set(wanted), set(index)
    if a != b:
        raise KeyMismatch(table.name, key, a - b, b - a)
    return index


def write_rows(buf, table, rows, key, fields):
    index = check_keys(table, buf, rows, key)
    n = 0
    for r in rows:
        i = index[int(r[key])]
        for f in fields:
            if f == key or f not in table.by_name or f not in r:
                continue
            table.put(buf, i, f, r[f])
            n += 1
    return n


def write_play(buf, play, rows, fields):
    return write_rows(buf, play, rows, "PGID", fields)


def write_prgr(buf, prgr, rows):
    return write_rows(buf, prgr, rows, "PGID", GEAR_FIELDS)
