"""Per-player eye color: a nibble per PGID (even PGID low nibble, odd high),
resolved through the base's LOOK table (skin * 8 + code - 1 -> CAP index)."""

EYE_KEYS = {1: "blue", 2: "blue_grey", 3: "green", 4: "hazel",
            5: "amber", 6: "light_brown", 7: "brown", 8: "dark_brown"}
AUTO_BY_SKIN = ["blue", "green", "hazel", "light_brown", "brown", "dark_brown",
                "brown", "dark_brown", "brown", "brown", "dark_brown", "dark_brown"]
N_SKINS, N_COLOURS = 12, 8


class LookMissing(ValueError):
    def __init__(self, pgid, skin, code):
        self.pgid, self.skin, self.code = pgid, skin, code
        super().__init__("PGID %d: %s eyes on skin tone %d are not built into this base"
                         % (pgid, EYE_KEYS.get(code, code), skin))


def encode_pgidtab(players, look, capacity):
    tab = bytearray(capacity)
    for p in players:
        code = int(p.get("EYEC") or 0)
        if code == 0:
            continue
        pgid, skin = int(p["PGID"]), int(p["PSKI"])
        if code not in EYE_KEYS:
            raise ValueError("PGID %d: eye color code %d is not one of 1..8" % (pgid, code))
        if not 0 <= skin < N_SKINS:
            raise ValueError("PGID %d: skin tone %d is out of range" % (pgid, skin))
        if EYE_KEYS[code] == AUTO_BY_SKIN[skin]:
            continue
        if pgid >= capacity * 2:
            raise ValueError("PGID %d is beyond this base's eye table (%d)" % (pgid, capacity * 2))
        if look[skin * N_COLOURS + code - 1] == 0:
            raise LookMissing(pgid, skin, code)
        i = pgid >> 1
        tab[i] = (tab[i] & 0x0F) | (code << 4) if pgid & 1 else (tab[i] & 0xF0) | code
    return bytes(tab)


def decode_pgidtab(tab):
    out = {}
    for i, b in enumerate(tab):
        if b & 0x0F:
            out[i * 2] = b & 0x0F
        if b >> 4:
            out[i * 2 + 1] = b >> 4
    return out
