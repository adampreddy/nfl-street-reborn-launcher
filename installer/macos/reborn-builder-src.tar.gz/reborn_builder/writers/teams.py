"""TEAM writer: game fields by TGID, plus deterministic CPAL allocation for colors."""
from ..colors import desired_ramp, export_shades, ramp_colors, ramp_from_slot, slot_bytes, to_hex
from .roster import check_keys

COLOR_FIELDS = ("TMC1", "TMC2", "TMC3")
N_SLOTS = 128


class PaletteFull(ValueError):
    pass


def write_team_fields(buf, team, rows):
    n = 0
    index = check_keys(team, buf, [{"TGID": r.tgid} for r in rows], "TGID")
    for r in rows:
        i = index[r.tgid]
        for f, v in r.fields.items():
            if f in COLOR_FIELDS or f == "TGID" or f not in team.by_name:
                continue
            team.put(buf, i, f, v)
            n += 1
    return n


def _slot_row(buf, cpal, j):
    o = cpal.rec_off(j)
    return bytes(buf[o:o + 16])


def _slot_colors(buf, cpal, j):
    return tuple(_slot_row(buf, cpal, j)[:12])


def _write_slot(buf, cpal, j, ramp):
    o = cpal.rec_off(j)
    buf[o:o + 16] = slot_bytes(ramp, j)


def read_colors(buf, team, cpal, i):
    out = {}
    for chan in (1, 2, 3):
        j = team.get(buf, i, "TMC%d" % chan)
        ramp = ramp_from_slot(_slot_row(buf, cpal, j))
        hx = to_hex(ramp["P"])
        out["c%d" % chan] = {"hex": hx, "shades": export_shades(ramp, hx)}
    return out


def write_colors(buf, team, cpal, rows):
    index = check_keys(team, buf, [{"TGID": r.tgid} for r in rows], "TGID")
    usage = {j: [] for j in range(N_SLOTS)}
    for i in range(team.capacity):
        for chan in (1, 2, 3):
            usage[team.get(buf, i, "TMC%d" % chan)].append((i, chan))
    taken, log = set(), []
    for r in sorted(rows, key=lambda r: r.tgid):
        if not r.colors:
            continue
        i = index[r.tgid]
        for chan in (1, 2, 3):
            spec = r.colors.get("c%d" % chan)
            if not isinstance(spec, dict) or not spec.get("hex"):
                raise ValueError("TGID %d: colors must carry c1, c2 and c3, each with a hex" % r.tgid)
            ramp = desired_ramp(spec["hex"], spec.get("shades"))
            want = ramp_colors(ramp)
            cur = team.get(buf, i, "TMC%d" % chan)
            if _slot_colors(buf, cpal, cur) == want:
                continue
            hit = next((j for j in range(N_SLOTS) if _slot_colors(buf, cpal, j) == want), None)
            if hit is not None:
                new = hit
                log.append("TGID %d color %d: slot %d -> %d (shares %s)" % (r.tgid, chan, cur, new, spec["hex"]))
            elif usage[cur] == [(i, chan)] and cur not in taken:
                _write_slot(buf, cpal, cur, ramp)
                taken.add(cur)
                log.append("TGID %d color %d: slot %d rewritten -> %s" % (r.tgid, chan, cur, spec["hex"]))
                continue
            else:
                free = [j for j in range(N_SLOTS) if not usage[j] and j not in taken]
                if not free:
                    raise PaletteFull("all 128 palette slots are in use; share a color between teams to free one")
                new = free[0]
                _write_slot(buf, cpal, new, ramp)
                log.append("TGID %d color %d: slot %d -> %d (new, %s)" % (r.tgid, chan, cur, new, spec["hex"]))
            taken.add(new)
            team.put(buf, i, "TMC%d" % chan, new)
            usage[cur].remove((i, chan))
            usage[new].append((i, chan))
    return log
