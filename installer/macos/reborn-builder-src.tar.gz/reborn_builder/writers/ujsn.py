"""The UJSN v5 table the Uniforms slider reads. Port of tools/bake_jersey_slots.py.

    header 24 B  >4sIIIII : 'UJSN', 5, 32, ROW, pool_off, pool_len
    row    20 B  u32 key | u8 count | u8 map[4] | u8 pad | u16 off[4] @0x0A | u16 captain @0x12
    pool         [u8 len][chars][NUL] per distinct name; offsets point at the chars;
                 zero padded so the whole table is a multiple of 16 bytes
"""
import struct

MAGIC = b"UJSN"
VERSION = 5
NTEAM = 32
ROW = 20
HDR = 24
KEY_LEN = 4
CAPT_OFF = 0x12
NO_CAPTAIN = 0xFFFF
NSLOT = 4
MAX_CHARS = 23
MAX_WIDTH = 179

ADVANCE = (5, 8, 9, 12, 12, 17, 15, 7, 7, 7, 10, 12, 7, 7, 7, 6, 12, 13, 12, 12, 12, 12, 12,
           12, 12, 12, 7, 7, 12, 12, 12, 10, 13, 14, 13, 14, 14, 12, 11, 14, 14, 7, 11, 14, 11,
           17, 14, 14, 13, 14, 13, 13, 12, 14, 14, 17, 14, 14, 12, 7, 6, 7, 12, 9, 7, 11, 12,
           11, 12, 11, 8, 12, 12, 7, 7, 12, 7, 17, 12, 12, 12, 12, 8, 10, 8, 12, 11, 16, 11,
           11, 10, 7, 6, 7, 12)
assert len(ADVANCE) == 95


def text_width(name):
    return sum(ADVANCE[ord(c) - 32] for c in name if 32 <= ord(c) < 127)


def validate_name(name):
    bad = []
    if not name:
        return ["empty"]
    if len(name) > MAX_CHARS:
        bad.append("%d characters, max %d" % (len(name), MAX_CHARS))
    non_ascii = [c for c in name if not (32 <= ord(c) < 127)]
    if non_ascii:
        bad.append("non-ASCII character(s) %s have no glyph in this font" % "".join(sorted(set(non_ascii))))
    else:
        w = text_width(name)
        if w > MAX_WIDTH:
            bad.append("%d px wide, max %d" % (w, MAX_WIDTH))
    return bad


def team_key(name):
    return (name.encode("ascii") + b"\0\0\0\0")[:KEY_LEN]


def encode(rows):
    rows = sorted(rows, key=lambda r: r[0])
    if len(rows) != NTEAM:
        raise ValueError("jersey table needs exactly %d teams, got %d" % (NTEAM, len(rows)))
    pool, where = bytearray(), {}

    def intern(name):
        b = name.encode("ascii")
        if b not in where:
            pool.append(len(b))
            where[b] = len(pool)
            pool.extend(b + b"\0")
        return where[b]

    body = bytearray()
    keys = []
    for name, slots, captain in rows:
        if not name or any(not 32 <= ord(c) < 127 for c in name):
            raise ValueError("team name %r must be non-empty printable ASCII" % (name,))
        if len(slots) != NSLOT:
            raise ValueError("%s: %d slots, expected %d" % (name, len(slots), NSLOT))
        for k, s in enumerate(slots):
            for reason in validate_name(s.get("name", "")):
                raise ValueError("%s slot %d (%r): %s" % (name, k, s.get("name", ""), reason))
        on = [k for k, s in enumerate(slots) if s.get("enabled")]
        if not on or on != list(range(len(on))):
            raise ValueError("%s: enabled slots must run from the first with no gaps (got %s)" % (name, on))
        row = bytearray(ROW)
        row[0:KEY_LEN] = team_key(name)
        keys.append(bytes(row[0:KEY_LEN]))
        row[4] = len(on)
        for pos, slot in enumerate(on):
            row[5 + pos] = slot
        for k, s in enumerate(slots):
            struct.pack_into(">H", row, 0x0A + k * 2, intern(s["name"]))
        if captain is not None and (not isinstance(captain, int) or isinstance(captain, bool)):
            raise ValueError("%s: captain must be a PGID number, got %r" % (name, captain))
        cap = NO_CAPTAIN if captain is None else captain
        if not 0 <= cap <= NO_CAPTAIN:
            raise ValueError("%s: captain PGID %d is out of range" % (name, cap))
        struct.pack_into(">H", row, CAPT_OFF, cap)
        body += row
    if len(set(keys)) != NTEAM:
        raise ValueError("two teams share the same first four letters; the game could not tell them apart")
    while (HDR + len(body) + len(pool)) % 16:
        pool.append(0)
    hdr = struct.pack(">4sIIIII", MAGIC, VERSION, NTEAM, ROW, HDR + len(body), len(pool))
    return bytes(hdr + body + pool)


def decode(blob):
    try:
        magic, version, nteam, row_len, pool_off, pool_len = struct.unpack_from(">4sIIIII", blob, 0)
        if magic != MAGIC or version != VERSION or row_len != ROW:
            raise ValueError("not a UJSN v5 table")
        if len(blob) < HDR + nteam * ROW or pool_off + pool_len > len(blob):
            raise ValueError("not a UJSN v5 table, or it is truncated")
        out = {}
        for t in range(nteam):
            o = HDR + t * ROW
            key = bytes(blob[o:o + KEY_LEN])
            count = blob[o + 4]
            enabled = set(blob[o + 5:o + 5 + count])
            slots = []
            for k in range(NSLOT):
                off_rel = struct.unpack_from(">H", blob, o + 0x0A + k * 2)[0]
                if not 1 <= off_rel <= pool_len:
                    raise ValueError("UJSN name offset out of range")
                off = pool_off + off_rel
                ln = blob[off - 1]
                slots.append({"name": bytes(blob[off:off + ln]).decode("ascii"), "enabled": k in enabled})
            cap = struct.unpack_from(">H", blob, o + CAPT_OFF)[0]
            out[key] = {"slots": slots, "captain_pgid": None if cap == NO_CAPTAIN else cap}
        return out
    except (struct.error, IndexError, UnicodeDecodeError):
        raise ValueError("not a UJSN v5 table, or it is truncated")
