"""Jersey number placement: two 64-byte tables of block codes, index team*2 + side.
Port of tools/patch_number_placement.py (tables only; the caves are the base's)."""

TEAMS = ["Bears", "Bengals", "Bills", "Broncos", "Browns", "Buccaneers", "Cardinals", "Chargers",
         "Chiefs", "Colts", "Cowboys", "Dolphins", "Eagles", "Falcons", "49ers", "Giants", "Jaguars",
         "Jets", "Lions", "Packers", "Panthers", "Patriots", "Raiders", "Rams", "Ravens", "Redskins",
         "Saints", "Seahawks", "Steelers", "Texans", "Titans", "Vikings"]
SIDES = ("away", "home")
LABELS = ("shoulder", "sleeve", "none")
BLOCKS = [0x80048364, 0x80048240, 0x80048320, 0x80048344, 0x80048218, 0x80048264]
CODE_OF_BLOCK = {b: i for i, b in enumerate(BLOCKS)}
CODE_PLACEMENT = {0: "none", 1: "sleeve", 2: "shoulder", 3: "none", 4: "shoulder", 5: "shoulder"}
USER_CODE = {"none": 0, "sleeve": 1, "shoulder": 2}


def stock_reg_block(k):
    r9 = k + 1
    if k == 0xf: return 0x80048320
    if r9 > 0x10:
        if r9 == 0x19: return 0x80048218
        if r9 > 0x19:
            if r9 == 0x1d: return 0x80048320
            if r9 <= 0x1d:
                if r9 == 0x1b: return 0x80048218
                if r9 > 0x1b: return 0x80048264
                return 0x80048240
            if r9 == 0x1e: return 0x80048240
            if r9 > 0x20: return 0x80048364
            return 0x80048264
        if r9 > 0x16:
            if r9 == 0x17: return 0x80048240
            if r9 == 0x18: return 0x80048264
            return 0x80048364
        if r9 >= 0x15: return 0x80048264
        if r9 == 0x11: return 0x80048264
        return 0x80048320
    if r9 == 7: return 0x80048240
    if r9 > 7:
        if r9 == 0xc: return 0x80048264
        if r9 > 0xc:
            if r9 == 0xe: return 0x80048264
            if r9 > 0xe: return 0x80048218
            return 0x80048320
        if r9 <= 0xa: return 0x80048240
        return 0x80048320
    if r9 == 3: return 0x80048240
    if r9 > 3:
        if r9 <= 5: return 0x80048320
        return 0x80048264
    if r9 == 1: return 0x80048240
    if r9 == 2: return 0x80048320
    return 0x80048364


def stock_tb_block(k):
    r4 = k + 1
    if r4 > 0x14:
        if r4 > 0x17:
            if r4 == 0x18: return 0x80048344
            if r4 > 0x20: return 0x80048364
            return 0x80048320
        if r4 >= 0x16: return 0x80048320
        return 0x80048344
    if r4 >= 0xb: return 0x80048320
    if r4 == 8: return 0x80048344
    if r4 > 8:
        if r4 == 9: return 0x80048320
        if r4 == 0xa: return 0x80048344
        return 0x80048364
    if r4 < 1: return 0x80048364
    return 0x80048320


def _table(section, stock_fn):
    tbl = bytearray(64)
    for k, name in enumerate(TEAMS):
        stock_code = CODE_OF_BLOCK[stock_fn(k)]
        stock_label = CODE_PLACEMENT[stock_code]
        entry = (section or {}).get(k + 1) or {}
        for si, side in enumerate(SIDES):
            raw = entry.get(side)
            if raw is not None and not isinstance(raw, str):
                raise ValueError("%s %s placement must be a word, got %r" % (name, side, raw))
            req = (raw or "").lower()
            if req and req not in USER_CODE:
                raise ValueError("%s %s placement %r is not one of %s" % (name, side, req, ", ".join(LABELS)))
            tbl[k * 2 + si] = USER_CODE[req] if (req and req != stock_label) else stock_code
    return bytes(tbl)


def encode(by_tgid):
    bad = sorted(t for t in (by_tgid or {}) if t not in range(1, len(TEAMS) + 1))
    if bad:
        raise ValueError("placement given for TGID %s; only teams 1..%d have number placement" % (bad, len(TEAMS)))
    reg = {t: v.get("regular") for t, v in (by_tgid or {}).items()}
    tb = {t: v.get("throwback") for t, v in (by_tgid or {}).items()}
    return _table(reg, stock_reg_block), _table(tb, stock_tb_block)


def decode(reg64, tb64):
    if len(reg64) < 64 or len(tb64) < 64:
        raise ValueError("placement tables must be 64 bytes each (got %d and %d)" % (len(reg64), len(tb64)))
    out = {}
    for k in range(len(TEAMS)):
        out[k + 1] = {
            "regular": {"away": CODE_PLACEMENT.get(reg64[k * 2], "shoulder"),
                        "home": CODE_PLACEMENT.get(reg64[k * 2 + 1], "shoulder")},
            "throwback": {"away": CODE_PLACEMENT.get(tb64[k * 2], "shoulder"),
                          "home": CODE_PLACEMENT.get(tb64[k * 2 + 1], "shoulder")},
        }
    return out
