"""GameCube memory card images, by the layout proven on real cards.

Card: 0x2000-byte blocks. Two directory copies at 0x2000 and 0x4000 (127 entries of 0x40
bytes; the newer copy has the higher u16 counter at +0x1FFA). Two block allocation tables
at 0x6000 and 0x8000 (newer by the u16 counter at +0x04); the entry for block b is the u16
at +0x0A + (b - 5) * 2 naming the next block, 0xFFFF ending the chain. Data blocks start
at 5.

Directory entry: gamecode at 0..6, filename at 8..0x28 NUL padded, save stamp at 0x28 (u32,
seconds since 2000-01-01 as the console's LOCAL wall clock, no zone), first block at 0x36
(u16), block count at 0x38 (u16).

An NFL Street 2 profile save is GN7E-69UserID<profile>: a 0x40 comment, a 0x800 icon, then
the game's profile database at 0x840, which holds PRGR. Nothing here knows the roster.
"""
import os
import struct
from collections import namedtuple
from datetime import datetime, timedelta

from .tdb import find_db

BLK = 0x2000
DIR_OFFS = (0x2000, 0x4000)
BAT_OFFS = (0x6000, 0x8000)
MIN_CARD = 0xA000
GC_EPOCH = datetime(2000, 1, 1)
GAMECODE = "GN7E69"

Save = namedtuple("Save", "slot gamecode filename profile stamp first count")


def _newer(card, offs, counter_at):
    a, b = (struct.unpack(">H", card[o + counter_at:o + counter_at + 2])[0] for o in offs)
    return offs[0] if a >= b else offs[1]


def list_saves(card):
    """Every entry of the newer directory copy, in slot order."""
    if len(card) < MIN_CARD:
        raise ValueError("not a memory card image: %d bytes" % len(card))
    d = _newer(card, DIR_OFFS, 0x1FFA)
    out = []
    for i in range(127):
        e = bytes(card[d + i * 0x40:d + (i + 1) * 0x40])
        if e[0:4] == b"\xff\xff\xff\xff":
            continue
        filename = e[8:0x28].split(b"\x00")[0].decode("ascii", "replace")
        profile = filename.split("UserID", 1)[1] if "UserID" in filename else filename
        out.append(Save(i, e[0:6].decode("ascii", "replace"), filename, profile,
                        struct.unpack(">I", e[0x28:0x2C])[0],
                        struct.unpack(">H", e[0x36:0x38])[0],
                        struct.unpack(">H", e[0x38:0x3A])[0]))
    return out


def profile_saves(card):
    """The NFL Street 2 profile saves. Options saves and other games are not."""
    return [s for s in list_saves(card) if s.gamecode == GAMECODE and "UserID" in s.filename]


def stamp_local(save):
    """The save's clock as a naive local wall-clock datetime. Never zone-convert it."""
    return GC_EPOCH + timedelta(seconds=save.stamp)


def block_chain(card, first, count):
    bat = _newer(card, BAT_OFFS, 4)
    chain, b = [], first
    while b not in (0, 0xFFFF) and len(chain) < count:
        if b < 5 or (b + 1) * BLK > len(card):
            raise ValueError("block chain points outside the card (block %d)" % b)
        chain.append(b)
        p = bat + 0x0A + (b - 5) * 2
        b = struct.unpack(">H", card[p:p + 2])[0]
    if len(chain) != count:
        raise ValueError("block chain broke after %d of %d blocks" % (len(chain), count))
    return chain


def read_blob(card, chain):
    return b"".join(bytes(card[x * BLK:(x + 1) * BLK]) for x in chain)


def card_offset(chain, blob_off):
    """Where a byte of the reassembled save lives on the card."""
    return chain[blob_off // BLK] * BLK + blob_off % BLK


def find_profile_db(blob):
    """The one embedded database holding PRGR. Scans every header; refuses ambiguity."""
    return find_db(blob, {"PRGR"})


def write_card(path, data):
    """Write the whole image through a temp file and one rename; never leave a .part behind."""
    tmp = path + ".part"
    try:
        with open(tmp, "wb") as f:
            f.write(data)
        os.replace(tmp, path)
    except BaseException:
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise
