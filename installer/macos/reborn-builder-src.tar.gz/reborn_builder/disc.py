"""The disc. After a roster goes INTO the clean tree, the playable ISO is regenerated
from the tree by the tree's own tools and read back. Nothing here patches an ISO in
place, and nothing here is reported as done until check_build_sync.py has compared the
disc with the tree file by file.

This is the Build Sync Law (tools/check_build_sync.py) as code: ONE tree, ONE ISO. Until
2026-09-06 a root build stopped after Portraits, so the roster sat in root/ while Games/
still held the previous disc, and the Builder "did not actually build the ISO".

The four steps, in the order the roster checklist prescribes:

    Fix portraits       tools/fix_otc_face_portraits.py --apply
                        (keeps Own The City's generated faces off the NFL headshot slots
                        the new roster occupies)
    Check OTC roster    tools/verify_otc_roster.py --fix
                        (a roster import wipes the position groups; empty groups make
                        demigod street crews, and build_iso_fields.py refuses to pack)
    Build ISO           tools/build_iso_fields.py
                        (regenerates the disc from root/; its own gates abort the build)
    Check disc          tools/check_build_sync.py --record-roster <update>
                        tools/check_build_sync.py --no-launcher
                        (pins the roster now in root/ as canonical, then reads the disc
                        back against the tree: DOL, every file, the DOL invariants)
"""
import json
import os
import re
import subprocess
import sys
import time

from .errors import BuildError

DISC_STEPS = ("Fix portraits", "Check OTC roster", "Build ISO", "Check disc")
TOOLS = ("fix_otc_face_portraits.py", "verify_otc_roster.py", "build_iso_fields.py",
         "check_build_sync.py")
TAIL = 40
WROTE = re.compile(r"^wrote (.+\.iso)\s*$", re.IGNORECASE)


def tools_dir(root):
    """The clean tree's tools folder: the first tools/build_iso_fields.py found walking up
    from the root folder (<clean>/GameCube Version/root -> <clean>/tools). None when there
    is none, which is what a root folder that is not the clean tree looks like."""
    here = os.path.abspath(root)
    for _ in range(3):
        here = os.path.dirname(here)
        cand = os.path.join(here, "tools")
        if os.path.isfile(os.path.join(cand, "build_iso_fields.py")):
            return cand
    return None


def canonical_iso_name(tools):
    """The name build_iso_fields.py gives the disc, from registry.json field_ids (the same
    rule tools/check_build_sync.py applies). Empty when the registry cannot be read."""
    try:
        with open(os.path.join(tools, "field_importer", "registry.json"), encoding="utf-8") as f:
            ids = sorted(int(k) for k in json.load(f).get("field_ids", {}))
    except (OSError, ValueError, TypeError, AttributeError):
        return ""
    if not ids:
        return "NFL Street 2 STOCK.iso"
    if len(ids) == 1:
        return "NFL Street 2 FIELD %d.iso" % ids[0]
    if ids == list(range(ids[0], ids[-1] + 1)):
        return "NFL Street 2 FIELDS %d-%d.iso" % (ids[0], ids[-1])
    return "NFL Street 2 FIELDS %s.iso" % "+".join(str(i) for i in ids)


def python():
    """How to start a Python for the tree's tools. From source that is this interpreter.
    From the frozen exe sys.executable IS the exe, so use the py launcher, which is how
    every instruction in the tree names these tools (`py -3 tools/...`)."""
    if getattr(sys, "frozen", False):
        return ["py", "-3"]
    return [sys.executable]


def run(cmd, cwd, on_line):
    """Run one tool, handing each line of its output (stdout and stderr merged) to on_line
    as it arrives. Returns the exit code. The seam the tests replace."""
    env = dict(os.environ, PYTHONIOENCODING="utf-8", PYTHONUTF8="1")
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0) if sys.platform == "win32" else 0
    p = subprocess.Popen(cmd, cwd=cwd, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                         stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace",
                         env=env, creationflags=flags)
    for line in p.stdout:
        on_line(line.rstrip("\r\n"))
    return p.wait()


def wrote_path(lines):
    """The path on the last 'wrote <x>.iso' line, or ''."""
    found = ""
    for line in lines:
        m = WROTE.match(line)
        if m:
            found = m.group(1).strip()
    return found


def tail(lines, n=TAIL):
    return "\n".join(lines[-n:])


class DiscBuild:
    """Runs the four steps against the tree at `root` for the update at `update`.

    progress(i, state) follows pipeline.Build's protocol, with i counted from `first`
    (the index of "Fix portraits" in the step list the caller advertised). One extra
    state, ("line", text), carries a line of tool output for a console to show."""

    def __init__(self, root, update, progress=None, first=0, runner=None):
        self.root = os.path.abspath(root)
        self.update = os.path.abspath(update)
        self.progress = progress or (lambda *a: None)
        self.first = first
        self.runner = runner or run
        self.log = []
        self.timings = []
        self.iso = ""

    def _step(self, i):
        self.progress(self.first + i, "start")
        self._t0 = time.perf_counter()

    def _done(self, i):
        self.timings.append((DISC_STEPS[i], time.perf_counter() - self._t0))
        self.progress(self.first + i, "done")

    def _tool(self, i, clean, tools, name, *args):
        """Run one tool; return (its output lines, its exit code)."""
        cmd = python() + [os.path.join(tools, name)] + list(args)
        shown = "py -3 tools/%s %s" % (name, " ".join(args)) if args else "py -3 tools/%s" % name
        self.log.append("$ " + shown.rstrip())
        lines = []

        def on_line(text):
            lines.append(text)
            self.log.append("  " + text)
            self.progress(self.first + i, ("line", text))

        try:
            rc = self.runner(cmd, clean, on_line)
        except OSError as e:
            raise BuildError(DISC_STEPS[i], "Could not start %s: %s" % (shown, e.strerror or e))
        return lines, rc

    def run(self):
        tools = tools_dir(self.root)
        if not tools:
            raise BuildError(DISC_STEPS[0], "There is no tools folder beside %s, so no ISO can be rebuilt "
                                            "from it. Apply into the clean tree, or pass --no-iso to stop "
                                            "after the tree." % self.root)
        clean = os.path.dirname(tools)

        self._step(0)
        out, rc = self._tool(0, clean, tools, "fix_otc_face_portraits.py", "--apply")
        if rc:
            raise BuildError(DISC_STEPS[0], "fix_otc_face_portraits.py stopped with exit code %d; the details "
                                            "hold what it said." % rc, tail(out))
        self._done(0)

        self._step(1)
        out, rc = self._tool(1, clean, tools, "verify_otc_roster.py", "--fix")
        if rc:
            raise BuildError(DISC_STEPS[1], "The roster fails Own The City's checks and not all of them are "
                                            "auto-fixable; the details name the tool for each.", tail(out))
        self._done(1)

        self._step(2)
        out, rc = self._tool(2, clean, tools, "build_iso_fields.py")
        if rc:
            if any("PermissionError" in line for line in out):
                raise BuildError(DISC_STEPS[2], "Dolphin has the ISO open, so it could not be rewritten. Close "
                                                "the game (Dolphin's game list is fine) and apply again.",
                                 tail(out))
            raise BuildError(DISC_STEPS[2], "build_iso_fields.py refused to build the disc; the details list "
                                            "its gate failures.", tail(out))
        iso = wrote_path(out)
        if not iso or not os.path.isfile(iso):
            raise BuildError(DISC_STEPS[2], "build_iso_fields.py finished without naming the ISO it wrote.",
                             tail(out))
        self.iso = os.path.abspath(iso)
        self._done(2)

        self._step(3)
        out, rc = self._tool(3, clean, tools, "check_build_sync.py", "--record-roster", self.update)
        if rc:
            raise BuildError(DISC_STEPS[3], "check_build_sync.py could not pin the roster (exit code %d); the "
                                            "details hold what it said." % rc, tail(out))
        out, rc = self._tool(3, clean, tools, "check_build_sync.py", "--no-launcher")
        if rc:
            fails = [line for line in out if line.startswith("FAIL")]
            raise BuildError(DISC_STEPS[3], "The rebuilt disc did not read back as the clean tree; the details "
                                            "list the FAIL lines. Do not play it until this is fixed.",
                             "\n".join(fails) if fails else tail(out))
        self._done(3)
        return self.iso
