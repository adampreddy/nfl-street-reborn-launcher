"""A native window over Edge WebView2. Every decision this window makes lives in
uiapi.py; this file only opens the window, serves three static files on 127.0.0.1, and
lets the worker thread inside Api get on with the build."""
import ctypes
import functools
import http.server
import os
import sys
import threading
import webbrowser

from . import VERSION
from .locate import webview2_version
from .uiapi import Api

WEBVIEW2_URL = "https://developer.microsoft.com/microsoft-edge/webview2/"
NO_WEBVIEW2 = ("Reborn Builder needs the Microsoft Edge WebView2 Runtime, and it is not "
               "installed on this PC.\n\n"
               "Click OK to open the Microsoft download page, then run Reborn Builder again.")
NO_PYWEBVIEW = ("Reborn Builder could not start its window (pywebview is not installed).\n\n"
                "Run: py -3 -m pip install pywebview")


class _Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *args):
        pass


def ui_dir():
    """The folder holding index.html, app.css and app.js. PyInstaller unpacks bundled
    data beside the package, so this is right both frozen and from source."""
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "ui")


def serve(directory):
    """A private static server on 127.0.0.1, on whatever port the OS hands out. The page
    needs an http origin rather than file:// so navigator.clipboard works."""
    handler = functools.partial(_Quiet, directory=directory)
    httpd = http.server.ThreadingHTTPServer(("127.0.0.1", 0), handler)
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    return "http://127.0.0.1:%d/index.html" % httpd.server_address[1], httpd


def say(message, url=""):
    """A native message box. A missing renderer cannot be told about in a web page."""
    print(message, file=sys.stderr)
    if sys.platform != "win32":
        return
    MB_OKCANCEL, MB_ICONINFORMATION, IDOK = 0x1, 0x40, 1
    answer = ctypes.windll.user32.MessageBoxW(None, message, "Reborn Builder",
                                              MB_OKCANCEL | MB_ICONINFORMATION)
    if url and answer == IDOK:
        webbrowser.open(url)


class Dialogs:
    """The native file dialogs, behind the seam uiapi.Api takes."""

    def __init__(self, window, file_dialog):
        # Underscored on purpose. pywebview walks the js_api object's public attributes to
        # build the JS bridge, and this object hangs off it; a public reference to the live
        # Window sends that walk down into WinForms and COM internals, which floods the log
        # with recursion errors on every launch and can stall the window's UI thread.
        self._w, self._D = window, file_dialog

    def _one(self, kind, **kw):
        got = self._w.create_file_dialog(kind, **kw)
        if not got:
            return None
        return got if isinstance(got, str) else got[0]

    def open_iso(self):
        return self._one(self._D.OPEN, file_types=("GameCube ISO (*.iso)",))

    def open_update(self):
        return self._one(self._D.OPEN, file_types=("Roster update (*.rebornroster)",))

    def save_iso(self, suggested):
        return self._one(self._D.SAVE, directory=os.path.dirname(suggested or ""),
                         save_filename=os.path.basename(suggested or ""))

    def open_folder(self):
        return self._one(self._D.FOLDER)


def run(update_path=None):
    if webview2_version() is None:
        say(NO_WEBVIEW2, WEBVIEW2_URL)
        return 1
    try:
        import webview
        from webview import FileDialog
        from webview.dom import DOMEventHandler
    except ImportError:
        say(NO_PYWEBVIEW)
        return 1

    url, httpd = serve(ui_dir())
    api = Api(update_path=update_path)
    window = webview.create_window("Reborn Builder " + VERSION, url, js_api=api,
                                   width=600, height=700, min_size=(520, 600),
                                   background_color="#1e1e20")
    api.dialogs = Dialogs(window, FileDialog)
    api.closer = window.destroy

    def on_drop(event):
        # WebView2 hands pywebview the real path alongside the DOM event, but only for
        # listeners registered through window.dom, which is why this is not in app.js.
        files = (event.get("dataTransfer") or {}).get("files") or []
        for f in files:
            path = f.get("pywebviewFullPath") or ""
            if path.lower().endswith(".rebornroster"):
                api.choose_update(path)
                window.run_js("window.rb.refresh()")
                return
        window.run_js("window.rb.dropRefused()")

    def on_loaded():
        zone = window.dom.get_element("#drop")
        if zone is None:
            return
        zone.events.dragover += DOMEventHandler(lambda e: None, prevent_default=True)
        zone.events.drop += DOMEventHandler(on_drop, prevent_default=True)

    def on_closing():
        if api.phase != "building":
            return True
        return window.create_confirmation_dialog(
            "Reborn Builder",
            "A build is running. Close anyway? The new ISO will not be finished.")

    def on_shown():
        from . import assoc
        if not getattr(sys, "frozen", False) or assoc.is_registered() or assoc.already_asked():
            return
        if window.create_confirmation_dialog("Reborn Builder",
                                             "Open .rebornroster files with Reborn Builder?"):
            assoc.register(sys.executable)
        else:
            assoc.mark_asked()

    window.events.loaded += on_loaded
    window.events.closing += on_closing
    window.events.shown += on_shown
    try:
        webview.start(gui="edgechromium")
    finally:
        httpd.shutdown()
    return 0
