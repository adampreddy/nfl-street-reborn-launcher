"""Portrait textures into Reborn Dolphin's Load/Textures folder.

Overwrite, never delete: the pack holds far more than we ship, and an update that
removed anything it did not recognise would eat hand-made art.

The ONE exception is a portrait's own other-extension twin. The site sends DDS
when its host has a BC7 encoder and PNG when it does not, so the same face can
arrive under either name. Dolphin loads whichever of `name.dds` and `name.png` it
happens to find first, so leaving the old one in place lets a stale face silently
beat the one that was just delivered. Replacing a portrait therefore retires its
twin.
"""
import os

#: Portrait textures may arrive under either of these. See the note above.
_TWINS = {".dds": ".png", ".png": ".dds"}


def _retire_twin(dst):
    """Remove the same texture under the other extension, if it is sitting there."""
    stem, ext = os.path.splitext(dst)
    other = _TWINS.get(ext.lower())
    if not other:
        return
    for candidate in (stem + other, stem + other.upper()):
        try:
            os.remove(candidate)
        except OSError:
            pass  # not there, or not ours to remove; the write below is what matters


class PortraitError(Exception):
    """A partial failure: `count` portraits were copied before this one failed."""

    def __init__(self, count, message):
        super().__init__(message)
        self.count = count


def copy_portraits(update, textures_root):
    root = os.path.abspath(str(textures_root))
    n = 0
    for name in update.texture_names:
        rel = name[len("textures/"):]
        dst = os.path.abspath(os.path.join(root, *rel.split("/")))
        if os.path.commonpath([root, dst]) != root:
            raise ValueError("unsafe portrait name: %s" % name)
        try:
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            part = dst + ".part"
            with open(part, "wb") as f:
                f.write(update.read_texture(name))
            os.replace(part, dst)
            _retire_twin(dst)
        except OSError as e:
            raise PortraitError(n, str(e)) from e
        n += 1
    return n
