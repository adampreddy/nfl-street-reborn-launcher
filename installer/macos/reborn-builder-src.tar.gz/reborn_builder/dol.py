"""GameCube DOL: 7 text + 11 data sections; offsets at 0x00/0x1C, load
addresses at 0x48/0x64, sizes at 0x90/0xAC."""
import struct


class Dol:
    def __init__(self, data):
        self.data = bytes(data)
        d = self.data
        self.sections = []
        for i in range(7):
            o, a, s = (struct.unpack_from(">I", d, b + i * 4)[0] for b in (0x00, 0x48, 0x90))
            if s:
                self.sections.append((o, a, s, "text%d" % i))
        for i in range(11):
            o, a, s = (struct.unpack_from(">I", d, b + i * 4)[0] for b in (0x1C, 0x64, 0xAC))
            if s:
                self.sections.append((o, a, s, "data%d" % i))
        if not self.sections:
            raise ValueError("the DOL has no sections")
        self.length = max(o + s for o, a, s, n in self.sections)

    def va2off(self, va):
        for o, a, s, n in self.sections:
            if a <= va < a + s:
                return o + (va - a)
        raise LookupError("0x%08x is not inside any DOL section" % va)

    def off2va(self, off):
        for o, a, s, n in self.sections:
            if o <= off < o + s:
                return a + (off - o)
        raise LookupError("file offset 0x%x is not inside any DOL section" % off)

    def read(self, va, n):
        o = self.va2off(va)
        for _, a, s, _ in self.sections:
            if a <= va < a + s:
                if va + n > a + s:
                    raise LookupError("0x%08x..0x%08x crosses a section boundary" % (va, va + n))
                break
        return self.data[o:o + n]

    def find(self, needle):
        out, p = [], 0
        while True:
            p = self.data.find(needle, p)
            if p < 0:
                return out
            try:
                out.append(self.off2va(p))
            except LookupError:
                pass
            p += 1
