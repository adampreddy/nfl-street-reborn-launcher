"""The card-sync verb: every profile save on a memory card brought up to date with a roster
update, the member's in-game edits kept. Orchestration only; card.py knows the card and
gear_sync.py makes the decisions.

State file: {"format": 1, "profiles": {<profile>: Profile.to_json()}}. Absent or unreadable
means every profile bootstraps from the update's history; it is never a loss.
"""
import hashlib
import json
import os
from datetime import datetime

from . import card as cardio
from .gear_sync import Profile, STATE_FORMAT, check_history, roster_view, sync_profile
from .update import RosterUpdate
from .writers.roster import GEAR_FIELDS


def load_state(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            d = json.load(f)
    except (OSError, ValueError):
        return {"format": STATE_FORMAT, "profiles": {}}
    if not isinstance(d, dict) or d.get("format") != STATE_FORMAT or not isinstance(d.get("profiles"), dict):
        return {"format": STATE_FORMAT, "profiles": {}}
    return d


def save_state(path, state):
    parent = os.path.dirname(os.path.abspath(path))
    os.makedirs(parent, exist_ok=True)
    tmp = path + ".part"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(state, f, indent=1, sort_keys=True)
            f.write("\n")
        os.replace(tmp, path)
    except BaseException:
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise


def _sha256_of(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def run(card_path, update_path, state_path, dry_run=False, harvest_only=False, now=None):
    """Sync one card against one roster update. Returns the report lines."""
    with open(card_path, "rb") as f:
        original = f.read()
    image = bytearray(original)
    saves = cardio.profile_saves(image)
    with RosterUpdate.open(update_path) as upd:
        try:
            roster = roster_view(upd.players)
        except (KeyError, TypeError, ValueError) as e:
            raise ValueError("players.json row lacks or mistypes gear column %s" % e)
        history = upd.history()
    if history is not None:
        history = check_history(history)
    roster_sha = _sha256_of(update_path)
    state = load_state(state_path)
    profiles = {}
    for name, record in state["profiles"].items():
        try:
            profiles[name] = Profile.from_json(record)
        except (AttributeError, TypeError, ValueError, KeyError):
            pass  # an unreadable record means this profile bootstraps; never a loss
    written_at = (now or datetime.now()).strftime("%Y-%m-%dT%H:%M:%S")

    lines = ["card %s: %d profile(s)" % (os.path.basename(card_path), len(saves))]
    expected = {}
    for s in saves:
        try:
            chain = cardio.block_chain(image, s.first, s.count)
            blob = bytearray(cardio.read_blob(image, chain))
            table = cardio.find_profile_db(blob).tables["PRGR"]
            missing = [c for c in GEAR_FIELDS if c not in table.by_name]
            if missing:
                raise ValueError("gear table lacks %s" % ", ".join(missing))
            index = table.index(blob, "PGID")
            card_rows = {pgid: [table.get(blob, i, c) for c in GEAR_FIELDS] for pgid, i in index.items()}
            writes, new_state, rep = sync_profile(card_rows, roster, history, profiles.get(s.profile),
                                                  cardio.stamp_local(s), harvest_only)
            for pgid, target in writes.items():
                for c, v in zip(GEAR_FIELDS, target):
                    bits = table.by_name[c].bits
                    if v < 0 or v >> bits:
                        raise ValueError("PGID %d: %s=%d does not fit %d bits" % (pgid, c, v, bits))
        except (ValueError, LookupError) as e:
            lines.append("profile %s: skipped (%s)" % (s.profile, e))
            continue
        for pgid, target in writes.items():
            i = index[pgid]
            for c, v in zip(GEAR_FIELDS, target):
                table.put(blob, i, c, v)
            o = table.rec_off(i)
            for k in range(table.rec_len):
                expected[cardio.card_offset(chain, o + k)] = blob[o + k]
        new_state.roster_sha = roster_sha
        new_state.written_at = written_at
        profiles[s.profile] = new_state
        lines.append("profile %s: %s, updated %d, harvested %d, carried %d, skipped %d" % (
            s.profile, "bootstrap" if rep.bootstrap else "synced",
            rep.updated, rep.harvested, rep.carried, rep.skipped))

    changed = {off: b for off, b in expected.items() if original[off] != b}
    if dry_run:
        lines.append("would write %s: %d byte(s)" % (card_path, len(changed)))
        return lines
    if changed:
        for off, b in changed.items():
            image[off] = b
        cardio.write_card(card_path, bytes(image))
        try:
            with open(card_path, "rb") as f:
                back = f.read()
        except OSError as e:
            cardio.write_card(card_path, original)
            raise ValueError("the card could not be read back (%s); the original was put back" % e)
        if back != bytes(image):
            cardio.write_card(card_path, original)
            raise ValueError("the card did not read back as written; the original was put back")
        lines.append("wrote %s: %d byte(s) changed" % (card_path, len(changed)))
    else:
        lines.append("unchanged %s" % card_path)
    state["profiles"] = {k: v.to_json() for k, v in profiles.items()}
    try:
        save_state(state_path, state)
    except OSError as e:
        # The card and its record must agree: without the record the next run would file the
        # roster's own gear as the member's edits. Put the card back as it was.
        if changed:
            cardio.write_card(card_path, original)
        raise ValueError("the sync record %s could not be saved (%s); the card was put back as it was" % (state_path, e))
    return lines
