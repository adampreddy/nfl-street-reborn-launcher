"""Position groups: the 4-bit PLAY field PBPO at record bits [638,642).

Own The City builds its street crews by borrowing stats from roster players picked
BY POSITION GROUP, and the game expects players in every group 0..13 among the NFL
teams (TTYP 0): 0 QB, 1 RB, 2 WR, 3 WR3/TE, 4 OL, 5/6 DL, 7/8 LB, 9/10 DB, 11-13
specialists. A group with nobody in it makes the generator fall back to max stats
(85 in, 320 lb, every rating 164), which is the 7'1" "giant" crews.

The site keeps PBPO as the player's POSITION, in seven values {0,1,2,5,7,9,11}, and
every .rebornroster carries it that way, so a compose that writes PBPO faithfully
leaves seven groups empty. Proven 2026-09-12: the shipped Builder in ISO mode turned
the clean 9a6fdedb disc into one with groups 3,4,6,8,10,12,13 empty -- every player
whose launcher applied a roster got the giants, while the clean tree was saved by
tools/verify_otc_roster.py --fix, which only exists beside the tree.

`repair` is that tool's algorithm (tools/fix_position_groups.py, proven in game
2026-08-19), applied per team: surplus members of doubled groups move into the missing
ones, so players stay positionally plausible. It only fills a group the team lacks,
so a roster that already carries all fourteen groups is a fixed point (dump -> apply
round trips do not drift). `empty_groups` is the gate: the pipeline refuses to write an
image whose NFL teams leave any group empty.
"""
import collections

from .bits import rd_bits, wr_bits

GROUP_BIT, GROUP_LEN, GROUPS = 638, 4, 14
FIELD = "PBPO"
# Team Xzibit, the Legends and the created-team pool are not crew donors; TGID 0 is nobody.
SKIP_TGIDS = frozenset((0, 33, 34, 54))

# (source group, destination group, which surplus member moves, only on even TGIDs)
_MOVES = (
    (2, 3, 1, False),    # 2nd WR      -> WR3/TE       every team
    (5, 4, 0, True),     # one DL      -> OL           even TGIDs
    (5, 6, 0, False),    # one DL      -> DL2          odd TGIDs (see repair)
    (7, 8, 1, True),     # 2nd LB      -> LB2          even TGIDs
    (9, 10, 1, True),    # 2nd DB      -> DB2          even TGIDs
    (11, 12, 1, False),  # 2nd special -> 12           every team
    (11, 13, 2, False),  # 3rd special -> 13           where present
)


def group_of(buf, play, i):
    return rd_bits(buf, play.rec_off(i) * 8 + GROUP_BIT, GROUP_LEN)


def set_group(buf, play, i, value):
    wr_bits(buf, play.rec_off(i) * 8 + GROUP_BIT, GROUP_LEN, value)


def nfl_tgids(buf, team):
    """The TGIDs the crew generator draws donors from: TTYP 0 teams."""
    return {team.get(buf, i, "TGID") for i in range(team.count) if team.get(buf, i, "TTYP") == 0}


def distribution(buf, play, team):
    """Players per group among the NFL teams, as a Counter."""
    nfl = nfl_tgids(buf, team)
    dist = collections.Counter()
    for i in range(play.count):
        if play.get(buf, i, "TGID") in nfl:
            dist[group_of(buf, play, i)] += 1
    return dist


def empty_groups(dist):
    return [g for g in range(GROUPS) if dist.get(g, 0) == 0]


def repair(buf, play, team):
    """Re-tag surplus players on the NFL teams so every team covers the groups it can.
    Returns the number of players moved. Idempotent: a team that already has a
    destination group keeps its rows as they are. Only TTYP-0 teams are touched: they
    are the donors, and on the 2026-09-12 export this reproduces the clean tree's
    template.dat byte for byte (145 players moved)."""
    nfl = nfl_tgids(buf, team) - SKIP_TGIDS
    by_team = collections.defaultdict(lambda: collections.defaultdict(list))
    for i in range(play.count):
        tgid = play.get(buf, i, "TGID")
        if tgid not in nfl:
            continue
        by_team[tgid][group_of(buf, play, i)].append(i)

    moved = 0
    for tgid, groups in sorted(by_team.items()):
        even = tgid % 2 == 0
        for src, dst, nth, even_only in _MOVES:
            if even_only and not even:
                continue
            if src == 5 and dst == 6 and even:
                continue                     # even teams send their lineman to OL instead
            if groups.get(dst):
                continue                     # this team already covers the group
            rows = groups.get(src, [])
            if len(rows) > nth:
                row = rows[nth]
                set_group(buf, play, row, dst)
                groups[dst].append(row)
                moved += 1
    return moved
