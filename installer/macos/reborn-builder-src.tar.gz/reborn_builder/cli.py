"""Command line. Same code path as the window; this is what the launcher will call."""
import argparse
import os
import sys

from . import SUPPORTED_FORMAT_VERSIONS, VERSION
from .dump_current import dump_from_iso, dump_from_root
from .errors import BuildError
from .locate import default_out, textures_dir, today
from .pipeline import Build, BuildRequest, steps_for
from .root import Root
from .update import RosterUpdate, UpdateError


class Parser(argparse.ArgumentParser):
    """argparse exits 2 on bad arguments; this tool documents 4."""
    def error(self, message):
        self.print_usage(sys.stderr)
        print("%s: %s" % (self.prog, message), file=sys.stderr)
        sys.exit(4)


def result_lines(report):
    where = os.path.abspath(report.out) if report.is_root else os.path.basename(report.out)
    lines = ["Done",
             "%d players, %d teams, %d portraits written." % (report.counts["players"], report.counts["teams"],
                                                              report.counts["portraits"]),
             "%s - base %s - sha256 %s" % (where, report.base_label, report.sha256[:8])]
    if report.iso:
        lines.append("ISO rebuilt from the tree and read back: %s" % report.iso)
    if report.portrait_error:
        lines.append(report.portrait_error)
    if report.warnings:
        lines.append("%d warning(s) from the site:" % len(report.warnings))
        lines += ["  " + w for w in report.warnings]
    return lines


def write_log(report, lines):
    # report.out is the new ISO for an ISO build, or the root folder itself for a root
    # build (there is no single new file to sit the log beside in that case).
    dirpath = report.out if report.is_root else os.path.dirname(os.path.abspath(report.out))
    path = os.path.join(dirpath, "build-log.txt")
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n\n" + "\n".join(report.log) + "\n")
        for name, secs in report.timings:
            f.write("%-20s %.1fs\n" % (name, secs))
    return path


def build_parser():
    ap = Parser(prog="reborn-builder", description="Apply a roster update to an NFL Street 2 Reborn ISO.")
    ap.add_argument("--version", action="version",
                    version="reborn-builder %s (roster update format %d)" % (VERSION, max(SUPPORTED_FORMAT_VERSIONS)))
    sub = ap.add_subparsers(dest="cmd", parser_class=Parser)
    ap.add_argument("--iso", help="the ISO to build from")
    ap.add_argument("--root", help="the clean tree's root folder (template.dat, Streamed.db, "
                                   "&&systemdata/Start.dol), updated in place; the playable ISO is then "
                                   "rebuilt from it with the tree's own tools and read back")
    ap.add_argument("--update", help="the .rebornroster file")
    ap.add_argument("--out", help="the new ISO (default: beside the original, named by today's date); "
                                  "not valid with --root")
    ap.add_argument("--no-iso", action="store_true",
                    help="with --root: stop after the tree, do not rebuild the ISO")
    ap.add_argument("--textures", help="Reborn Dolphin's Load/Textures folder (default: found automatically)")
    ap.add_argument("--yes", action="store_true", help="build even if the site flagged problems")
    ap.add_argument("--assume-legacy-base", action="store_true", help=argparse.SUPPRESS)
    d = sub.add_parser("dump", help="write the ISO's current roster as a .rebornroster")
    d.add_argument("--iso")
    d.add_argument("--root", help="a folder holding template.dat, Streamed.db and &&systemdata/Start.dol")
    d.add_argument("--out", required=True)
    d.add_argument("--assume-legacy-base", action="store_true", help=argparse.SUPPRESS)
    c = sub.add_parser("card-sync", help="bring a memory card's gear up to date with a roster update, "
                                         "keeping the in-game edits")
    c.add_argument("--card", required=True, help="the .raw memory card image")
    c.add_argument("--update", required=True, help="the .rebornroster file")
    c.add_argument("--state", required=True, help="where this tool records what it last wrote to this card")
    c.add_argument("--harvest-only", action="store_true", help="record in-game edits; write nothing to the card")
    c.add_argument("--dry-run", action="store_true", help="say what would change; write nothing")
    return ap, d, c


def main(argv=None):
    ap, d, c = build_parser()
    a = ap.parse_args(argv)
    if a.cmd == "card-sync":
        from .card_sync import run as card_sync
        try:
            lines = card_sync(a.card, a.update, a.state, dry_run=a.dry_run, harvest_only=a.harvest_only)
        except PermissionError as e:
            print("Stopped: the memory card could not be written; if the game is running, close it and try again (%s)" % e,
                  file=sys.stderr)
            return 2
        except (OSError, ValueError, LookupError, UpdateError) as e:
            print("Stopped: %s" % e, file=sys.stderr)
            return 2
        except Exception as e:
            print("Stopped: unexpected error: %r" % e, file=sys.stderr)
            return 2
        for line in lines:
            print(line)
        return 0
    if a.cmd == "dump":
        out = os.path.abspath(a.out)
        if a.iso:
            inputs = [a.iso]
        elif a.root:
            r = Root(a.root)
            inputs = [r.template_path, r.streamed_path, r.dol_path]
        else:
            inputs = []
        if any(os.path.abspath(p) == out for p in inputs):
            print("Stopped: the output must not be one of the input files.", file=sys.stderr)
            return 2
        try:
            if a.iso:
                m = dump_from_iso(a.iso, a.out, a.assume_legacy_base)
            elif a.root:
                m = dump_from_root(a.root, a.out, a.assume_legacy_base)
            else:
                d.error("dump needs --iso or --root")
        except (OSError, ValueError, LookupError) as e:
            print("Stopped: %s" % e, file=sys.stderr)
            return 2
        print("wrote %s: %d players, %d teams, base %s" % (a.out, m["counts"]["players"], m["counts"]["teams"], m["base_label"]))
        return 0
    if a.root and a.iso:
        print("Stopped: --root and --iso cannot both be given; build from one or the other.", file=sys.stderr)
        return 4
    if a.root and a.out:
        print("Stopped: --out is not valid with --root; a root build writes into the root folder's own files.",
             file=sys.stderr)
        return 4
    if not a.update or not (a.iso or a.root):
        ap.print_usage(sys.stderr)
        print("reborn-builder: --update and one of --iso or --root are required", file=sys.stderr)
        return 4
    out = None if a.root else (a.out or default_out(a.iso, today()))
    try:
        with RosterUpdate.open(a.update) as upd:
            problems = upd.manifest.problem_lines()
    except UpdateError as e:
        print("Stopped at Check update file: %s" % e, file=sys.stderr)
        return 2
    if problems and not a.yes:
        print("%d thing(s) the site flagged; pass --yes to build anyway:" % len(problems), file=sys.stderr)
        for p in problems:
            print("  " + p, file=sys.stderr)
        return 3
    req = BuildRequest(iso=a.iso, update=a.update, out=out, textures_dir=a.textures or textures_dir(),
                       assume_legacy=a.assume_legacy_base, root=a.root, disc=not a.no_iso)
    steps = steps_for(req)

    def progress(i, state):
        if state == "start":
            print("%d/%d %s" % (i + 1, len(steps), steps[i]), flush=True)
        elif isinstance(state, tuple) and state[0] == "line":
            print("    " + state[1], flush=True)
    try:
        report = Build(req, progress).run()
    except BuildError as e:
        print("Stopped at %s: %s" % (e.step, e.sentence), file=sys.stderr)
        if e.details:
            print(e.details, file=sys.stderr)
        return 2
    lines = result_lines(report)
    print("\n".join(lines))
    try:
        print("log: " + write_log(report, lines))
    except OSError as e:
        print("Built, but could not write build-log.txt: %s" % (e.strerror or e), file=sys.stderr)
    return 0
