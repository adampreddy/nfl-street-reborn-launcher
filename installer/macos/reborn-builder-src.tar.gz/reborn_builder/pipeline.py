"""The eight steps (twelve into the clean tree, where the disc is rebuilt too). Nothing
is written until everything is checked; nothing is reported until it has been read back."""
import os
import struct
import time
from dataclasses import dataclass, field

from . import decals, disc, posgroups
from .directory import Directory, FILE_DOL
from .dol import Dol
from .dump_current import roster_dbs
from .errors import BuildError
from .gciso import Iso, patch_copy, verify_ranges
from .root import Root, restore_root, verify_root, write_root
from .textures import PortraitError, copy_portraits
from .update import RosterUpdate, UpdateError
from .writers import eyes, placement, ujsn
from .writers.roster import KeyMismatch, check_keys, write_play, write_prgr
from .writers.teams import PaletteFull, write_colors, write_team_fields

STEPS = ("Check update file", "Check ISO", "Match roster", "Compose", "Write", "Verify", "Portraits", "Done")
# Into the clean tree the job is not done until the playable ISO has been regenerated from
# the tree and read back, so the four disc steps sit between Portraits and Done.
ROOT_STEPS = STEPS[:7] + disc.DISC_STEPS + STEPS[7:]
NFL_TGIDS = range(1, 33)


@dataclass
class BuildRequest:
    """Exactly one of `iso` or `root` must be set. `out` (the new ISO) only makes
    sense with `iso`; a root build writes into the root folder's own files and then,
    unless `disc` is off, rebuilds the playable ISO from the tree."""
    iso: str = None
    update: str = None
    out: str = None
    textures_dir: str = None
    assume_legacy: bool = False
    root: str = None
    disc: bool = True


def steps_for(request):
    """The step names a build of this request will report, in order."""
    return ROOT_STEPS if (request.root and request.disc) else STEPS


@dataclass
class BuildReport:
    out: str
    sha256: str
    counts: dict
    base_label: str
    contract_version: int
    warnings: list = field(default_factory=list)
    log: list = field(default_factory=list)
    timings: list = field(default_factory=list)
    portrait_error: str = ""
    is_root: bool = False
    iso: str = ""


def _keys(keys):
    keys = sorted(keys)
    return ", ".join(str(k) for k in keys[:10]) + (", ..." if len(keys) > 10 else "")


def _mismatch(e, kind, key, src="ISO"):
    if e.missing_in_iso:
        return "The update has %d %s(s) this %s doesn't: %s %s." % (len(e.missing_in_iso), kind, src, key, _keys(e.missing_in_iso))
    return "This %s has %d %s(s) the update doesn't: %s %s." % (src, len(e.missing_in_update), kind, key, _keys(e.missing_in_update))


def _dbs_match(template2, streamed2, play, team, prgr_a, prgr_b, roster_db):
    """The same count/size checks both the ISO and the root path use to prove a
    freshly-read-back pair of files still holds the roster that was just written."""
    r2, p2, s2 = roster_dbs(template2, streamed2)
    return (r2.tables["PLAY"].count, r2.tables["TEAM"].count, p2.tables["PRGR"].count, s2.tables["PRGR"].count) == \
        (play.count, team.count, prgr_a.count, prgr_b.count) and r2.size == roster_db.size


class Build:
    def __init__(self, request, progress=None):
        self.req = request
        self.progress = progress or (lambda *a: None)
        self.log = []
        self.steps = steps_for(request)

    def _step(self, i):
        self.progress(i, "start")
        self._t0 = time.perf_counter()

    def _done(self, i, timings):
        timings.append((self.steps[i], time.perf_counter() - self._t0))
        self.progress(i, "done")

    def run(self):
        req, timings, log = self.req, [], self.log
        if req.iso and req.root:
            raise BuildError(STEPS[1], "Give either an ISO (--iso) or a root folder (--root), not both.")
        if not req.iso and not req.root:
            raise BuildError(STEPS[1], "Give an ISO (--iso) or a root folder (--root) to build into.")
        if req.root and req.out:
            raise BuildError(STEPS[1], "--out is not valid with --root; a root build writes into the root "
                                       "folder's own files, not a new one.")
        if req.iso and os.path.abspath(req.out) == os.path.abspath(req.iso):
            raise BuildError(STEPS[4], "The new ISO must be a different file from the one being built from.")

        self._step(0)
        try:
            upd = RosterUpdate.open(req.update)
        except UpdateError as e:
            raise BuildError(STEPS[0], str(e))
        try:
            return self._run_with_update(req, upd, timings, log)
        finally:
            upd.close()

    def _run_with_update(self, req, upd, timings, log):
        warnings = upd.manifest.problem_lines()
        self._done(0, timings)

        self._step(1)
        what = "root folder" if req.root else "ISO"
        try:
            src = Root(req.root) if req.root else Iso(req.iso)
            template, streamed, dol_bytes = src.read("template.dat"), src.read("Streamed.db"), src.read_dol()
            dol = Dol(dol_bytes)
        except (OSError, LookupError, ValueError, struct.error) as e:
            raise BuildError(STEPS[1], "Could not read the %s: %s" % (what, e))
        directory = Directory.parse(dol)
        if directory is None:
            if not req.assume_legacy:
                raise BuildError(STEPS[1], "This %s has no Reborn data directory, so it is older than this "
                                           "update needs. Get the newer base." % what)
            try:
                directory = Directory.legacy(dol)
            except ValueError as e:
                raise BuildError(STEPS[1], "This %s is not a Reborn base this builder recognizes (%s)." % (what, e))
        need = upd.manifest.requires_base
        if directory.contract_version < need:
            raise BuildError(STEPS[1], "This update needs base %s (version %d); your %s is base %s (version %d). "
                                       "Get the newer base." % (upd.manifest.base_label, need, what,
                                                                directory.label, directory.contract_version))
        for tag in ("UJSN", "PLCR", "PLCT", "EYPG", "EYLK"):
            if tag not in directory.entries:
                raise BuildError(STEPS[1], "This %s's data directory has no %s region; get the newer base." % (what, tag))
        self._done(1, timings)

        self._step(2)
        try:
            roster_db, profile_db, streamed_db = roster_dbs(template, streamed)
        except LookupError as e:
            raise BuildError(STEPS[2], "The %s's game database is not laid out as expected (%s)." % (what, e))
        play, team, cpal = roster_db.tables["PLAY"], roster_db.tables["TEAM"], roster_db.tables["CPAL"]
        prgr_a, prgr_b = profile_db.tables["PRGR"], streamed_db.tables["PRGR"]
        team_rows = [{"TGID": t.tgid} for t in upd.teams]
        try:
            check_keys(play, template, upd.players, "PGID")
            check_keys(prgr_a, template, upd.players, "PGID")
            check_keys(prgr_b, streamed, upd.players, "PGID")
        except KeyMismatch as e:
            raise BuildError(STEPS[2], _mismatch(e, "player", "PGID", what), str(e))
        except ValueError as e:
            raise BuildError(STEPS[2], str(e))
        try:
            check_keys(team, template, team_rows, "TGID")
        except KeyMismatch as e:
            raise BuildError(STEPS[2], _mismatch(e, "team", "TGID", what), str(e))
        except ValueError as e:
            raise BuildError(STEPS[2], str(e))
        self._done(2, timings)

        self._step(3)
        tbuf, sbuf, dbuf = bytearray(template), bytearray(streamed), bytearray(dol_bytes)
        try:
            n = write_play(tbuf, play, upd.players, upd.player_fields)
            log.append("PLAY: %d field writes" % n)
            log.append("PRGR: %d + %d field writes" % (write_prgr(tbuf, prgr_a, upd.players),
                                                        write_prgr(sbuf, prgr_b, upd.players)))
            log.append("TEAM: %d field writes" % write_team_fields(tbuf, team, upd.teams))
            log.extend(write_colors(tbuf, team, cpal, upd.teams))
        except PaletteFull as e:
            raise BuildError(STEPS[3], str(e))
        except (ValueError, TypeError) as e:
            raise BuildError(STEPS[3], "A value in the update does not fit its field: %s" % e)

        # Position groups (PBPO). The site sends positions in seven values, Own The City
        # needs players in all fourteen groups, and nothing downstream of an ISO build
        # fixes that: the Builder is the last thing that touches the roster before the
        # game reads it. Repair per team, then refuse to ship an image that would give
        # Own The City max-stat giants (see posgroups.py).
        moved = posgroups.repair(tbuf, play, team)
        log.append("Position groups: %d player(s) re-tagged so every group has NFL players" % moved)
        empty = posgroups.empty_groups(posgroups.distribution(tbuf, play, team))
        if empty:
            raise BuildError(STEPS[3], "Position groups %s have no players on NFL teams even after "
                                       "re-tagging, so Own The City would fill its street crews with "
                                       "max-stat giants. This update cannot be built." % empty)

        tidx = team.index(tbuf, "TGID")
        rows = []
        for t in upd.teams:
            if t.tgid not in NFL_TGIDS:
                continue
            if not t.jersey_slots:
                raise BuildError(STEPS[3], "Team %d has no jersey slots in the update." % t.tgid)
            rows.append((team.get(tbuf, tidx[t.tgid], "TDNA"), t.jersey_slots, t.captain_pgid))
        try:
            table = ujsn.encode(rows)
        except ValueError as e:
            raise BuildError(STEPS[3], "Jersey names: %s" % e)
        e_ujsn = directory.entries["UJSN"]
        if len(table) > e_ujsn.capacity:
            raise BuildError(STEPS[3], "The jersey names don't fit this base (%d bytes, room for %d)."
                                       % (len(table), e_ujsn.capacity))
        self._put(dbuf, dol, e_ujsn, table.ljust(e_ujsn.capacity, b"\x00"), what)
        log.append("UJSN: %d of %d bytes" % (len(table), e_ujsn.capacity))

        try:
            reg, tb = placement.encode({t.tgid: t.placement for t in upd.teams if t.placement})
        except ValueError as e:
            raise BuildError(STEPS[3], "Number placement: %s" % e)
        self._put(dbuf, dol, directory.entries["PLCR"], reg, what)
        self._put(dbuf, dol, directory.entries["PLCT"], tb, what)

        # DECL: the per-jersey decal table. An update carries ONE switch per team (the team
        # logo) and this is a READ-MODIFY-WRITE of just that bit, so the desktop CSV keeps
        # its other four columns for the same team. A base with no DECL entry is skipped, so
        # an older base still applies the rest of the update.
        e_decl = directory.entries.get("DECL")
        want = [t for t in upd.teams if t.decals is not None]
        if e_decl is not None and want:
            if e_decl.capacity != decals.TABLE_BYTES:
                raise BuildError(STEPS[3], "Region DECL is %d bytes, this builder expects %d; get the newer base."
                                           % (e_decl.capacity, decals.TABLE_BYTES))
            table = self._get(dbuf, dol, e_decl, what)
            n = 0
            for t in want:
                tlgl = team.get(tbuf, tidx[t.tgid], "TLGL")
                if not decals.in_range(tlgl):
                    warnings.append("Team %d has logo id %r, outside the decal table; its decal switch was skipped."
                                    % (t.tgid, tlgl))
                    continue
                table = decals.set_logo(table, tlgl, t.decals["team_logo"])
                n += 1
            self._put(dbuf, dol, e_decl, table, what)
            log.append("DECL: team logo set for %d team(s)" % n)
        elif want and e_decl is None:
            warnings.append("This base has no decal table (DECL); the jersey decal switches were ignored.")

        e_pg, e_lk = directory.entries["EYPG"], directory.entries["EYLK"]
        try:
            look = dol.read(e_lk.address, e_lk.capacity)
        except LookupError:
            raise BuildError(STEPS[3], "Region EYLK at 0x%08x is not inside this %s's DOL; get the newer base."
                                       % (e_lk.address, what))
        pidx = play.index(tbuf, "PGID")
        eye_rows = []
        for p in upd.players:
            skin = p.get("PSKI")
            if skin is None:
                skin = play.get(tbuf, pidx[int(p["PGID"])], "PSKI")
            eye_rows.append({"PGID": p["PGID"], "EYEC": p.get("EYEC", 0), "PSKI": skin})
        try:
            self._put(dbuf, dol, e_pg, eyes.encode_pgidtab(eye_rows, look, e_pg.capacity), what)
        except (ValueError, TypeError) as e:
            raise BuildError(STEPS[3], "Eye color: %s" % e)
        if not (len(tbuf) == len(template) and len(sbuf) == len(streamed) and len(dbuf) == len(dol_bytes)):
            raise BuildError(STEPS[3], "Internal error: a file changed size while composing.")
        self._done(3, timings)

        self._step(4)
        if req.root:
            try:
                sha, backups = write_root(req.root, tbuf, sbuf, dbuf,
                                          progress=lambda a, b: self.progress(4, ("bytes", a, b)))
            except OSError as e:
                raise BuildError(STEPS[4], "Could not write into %s: %s" % (req.root, e.strerror or e))
        else:
            writes = {src.extent("template.dat")[0]: bytes(tbuf), src.extent("Streamed.db")[0]: bytes(sbuf),
                     src.dol_off: bytes(dbuf)}
            try:
                sha = patch_copy(req.iso, req.out, writes,
                                 progress=lambda a, b: self.progress(4, ("bytes", a, b)))
            except OSError as e:
                raise BuildError(STEPS[4], "Could not write %s: %s" % (req.out, e.strerror or e))
        self._done(4, timings)

        self._step(5)
        if req.root:
            bad = verify_root(req.root, tbuf, sbuf, dbuf)
            ok = not bad
            if ok:
                try:
                    r2 = Root(req.root)
                    ok = _dbs_match(r2.read("template.dat"), r2.read("Streamed.db"), play, team, prgr_a, prgr_b, roster_db)
                except (OSError, LookupError, ValueError):
                    ok = False
            if not ok:
                try:
                    restore_root(backups)
                    restored = True
                except OSError:
                    restored = False
                if restored:
                    raise BuildError(STEPS[5], "The tree did not read back correctly; the previous files were "
                                               "restored. Try again, and check the disk.")
                raise BuildError(STEPS[5], "The tree did not read back correctly and could not be fully restored "
                                           "from backup; check %s yourself before building again." % req.root)
        else:
            bad = verify_ranges(req.out, writes)
            ok = not bad
            if ok:
                try:
                    out_iso = Iso(req.out)
                    ok = _dbs_match(out_iso.read("template.dat"), out_iso.read("Streamed.db"),
                                    play, team, prgr_a, prgr_b, roster_db)
                except (OSError, LookupError, ValueError):
                    ok = False
            if not ok:
                try:
                    os.remove(req.out)
                    removed = True
                except OSError:
                    removed = False
                if removed:
                    raise BuildError(STEPS[5], "The new ISO did not read back correctly and was deleted. Try again, and check the disk.")
                raise BuildError(STEPS[5], "The new ISO did not read back correctly and could not be deleted; delete it yourself. "
                                           "Try again, and check the disk.")
        self._done(5, timings)

        self._step(6)
        portraits = 0
        portrait_error = ""
        if req.textures_dir and upd.texture_names:
            try:
                portraits = copy_portraits(upd, req.textures_dir)
            except PortraitError as e:
                portraits = e.count
                portrait_error = "Portraits were not copied: %s" % e
            except (OSError, ValueError) as e:
                portrait_error = "Portraits were not copied: %s" % e
        self._done(6, timings)

        iso = ""
        if req.root and req.disc:
            # The tree now carries the roster; the disc must too, or nobody can play it.
            d = disc.DiscBuild(req.root, req.update, progress=self.progress, first=7)
            try:
                iso = d.run()
            finally:
                log.extend(d.log)
                timings.extend(d.timings)

        last = len(self.steps) - 1
        self._step(last)
        counts = {"players": len(upd.players), "teams": len(upd.teams), "portraits": portraits}
        self._done(last, timings)
        return BuildReport(req.root if req.root else req.out, sha, counts, directory.label, directory.contract_version,
                           warnings, log, timings, portrait_error, bool(req.root), iso)

    @staticmethod
    def _get(dbuf, dol, entry, what="ISO"):
        """The bytes of a DOL region as they stand in the buffer being written."""
        try:
            o = dol.va2off(entry.address)
        except LookupError:
            raise BuildError(STEPS[3], "Region %s at 0x%08x is not inside this %s's DOL; get the newer base."
                                       % (entry.tag, entry.address, what))
        return bytes(dbuf[o:o + entry.capacity])

    @staticmethod
    def _put(dbuf, dol, entry, data, what="ISO"):
        if entry.file != FILE_DOL:
            raise BuildError(STEPS[3], "Region %s is not in the DOL; this builder does not know how to write it." % entry.tag)
        if len(data) > entry.capacity:
            raise BuildError(STEPS[3], "Region %s needs %d bytes, the base reserved %d." % (entry.tag, len(data), entry.capacity))
        try:
            o = dol.va2off(entry.address)
        except LookupError:
            raise BuildError(STEPS[3], "Region %s at 0x%08x is not inside this %s's DOL; get the newer base."
                                       % (entry.tag, entry.address, what))
        try:
            dol.va2off(entry.address + len(data) - 1)
            a, s = next((a, s) for _, a, s, _ in dol.sections if a <= entry.address < a + s)
            if entry.address + len(data) > a + s:
                raise LookupError()
        except LookupError:
            raise BuildError(STEPS[3], "Region %s runs past the end of its DOL section; get the newer base." % entry.tag)
        dbuf[o:o + len(data)] = data
