"""The per-jersey decal table, region tag DECL.

160 TLGL rows x 4 uniforms (Home, Away, Alternate 1, Alternate 2) x one mask byte. A set bit
suppresses one class of decal on that jersey:

    bit 1  the jersey number
    bit 2  the team wordmark
    bit 3  the secondary logo      (the game reaches it from two kinds; both are bit 3 and 4)
    bit 4  the secondary logo, second kind
    bit 5  THE TEAM LOGO           <- the only one a football jersey draws besides its number
    bit 6  generic decal art       (every kind >= 6 collapses onto this bit)

A roster update only ever touches bit 5, by design. Bit 5 is what the site's team page
exposes, per uniform; the other five belong to the desktop CSV (tools/jersey_decals.py),
which authors street-gear decals. Read-modify-write means both can own the same team without
either clobbering the other.

The table is a region, not a patch: the cave code that reads it is part of the base, so a
roster update never writes code. An older base has no DECL entry and this is skipped.
"""
N_UNIFORMS = 4
N_TLGL_ROWS = 160
TABLE_BYTES = N_TLGL_ROWS * N_UNIFORMS
LOGO_BIT = 5
LOGO_MASK = 1 << LOGO_BIT

# index into a team's four bytes; the same order the cave derives from the uniform stamp
UNIFORMS = ("home", "away", "alt1", "alt2")


def in_range(tlgl):
    return isinstance(tlgl, int) and 0 <= tlgl < N_TLGL_ROWS


def logo_shown(table, tlgl):
    """{uniform: bool} -- is the team logo drawn on each of this team's four jerseys."""
    if not in_range(tlgl):
        return {u: True for u in UNIFORMS}
    return {u: not (table[tlgl * N_UNIFORMS + i] & LOGO_MASK)
            for i, u in enumerate(UNIFORMS)}


def _as_per_uniform(show):
    """A bare bool means all four, which is how a one-switch caller keeps working."""
    if isinstance(show, bool):
        return {u: show for u in UNIFORMS}
    if isinstance(show, dict):
        missing = [u for u in UNIFORMS if u not in show]
        if missing:
            raise ValueError("decals.team_logo is missing %s" % ", ".join(missing))
        return {u: bool(show[u]) for u in UNIFORMS}
    raise ValueError("decals.team_logo must be a bool or an object of four, got %s"
                     % type(show).__name__)


def set_logo(table, tlgl, show):
    """Return `table` with just the logo bit rewritten for one team.

    `show` is a bool (all four jerseys) or {"home":.., "away":.., "alt1":.., "alt2":..}.
    Every other bit of every byte is left exactly as it was.
    """
    if not in_range(tlgl):
        raise ValueError("tlgl %r is outside the %d-row decal table" % (tlgl, N_TLGL_ROWS))
    per = _as_per_uniform(show)
    out = bytearray(table)
    if len(out) != TABLE_BYTES:
        raise ValueError("decal table is %d bytes, expected %d" % (len(out), TABLE_BYTES))
    for i, u in enumerate(UNIFORMS):
        j = tlgl * N_UNIFORMS + i
        out[j] = (out[j] & ~LOGO_MASK) & 0xFF if per[u] else (out[j] | LOGO_MASK)
    return bytes(out)


def parse(value):
    """The `decals` object on a team row -> {"team_logo": {uniform: bool}}, or None.

    Unknown keys are dropped rather than rejected: a newer site can add one and an older
    builder should ignore it, not refuse the file. A bare bool is still accepted so a file
    written by the first, one-switch version of the site still applies.
    """
    if value is None:
        return None
    if not isinstance(value, dict):
        raise ValueError("decals must be an object, got %s" % type(value).__name__)
    if "team_logo" not in value:
        return None
    return {"team_logo": _as_per_uniform(value["team_logo"])}
