"""Per-user file association for .rebornroster (HKCU only, no elevation)."""
import sys

PROGID = "RebornBuilder.Update"
EXT = ".rebornroster"


def _winreg():
    if sys.platform != "win32":
        return None
    import winreg
    return winreg


def is_registered():
    wr = _winreg()
    if not wr:
        return True
    try:
        with wr.OpenKey(wr.HKEY_CURRENT_USER, r"Software\Classes\%s" % EXT) as k:
            return wr.QueryValue(k, "") == PROGID
    except OSError:
        return False


def already_asked():
    wr = _winreg()
    if not wr:
        return True
    try:
        with wr.OpenKey(wr.HKEY_CURRENT_USER, r"Software\RebornBuilder") as k:
            return wr.QueryValueEx(k, "asked")[0] == 1
    except OSError:
        return False


def mark_asked():
    wr = _winreg()
    if not wr:
        return
    try:
        with wr.CreateKey(wr.HKEY_CURRENT_USER, r"Software\RebornBuilder") as k:
            wr.SetValueEx(k, "asked", 0, wr.REG_DWORD, 1)
    except OSError:
        return


def register(exe_path):
    wr = _winreg()
    if not wr:
        return
    try:
        with wr.CreateKey(wr.HKEY_CURRENT_USER, r"Software\Classes\%s" % EXT) as k:
            wr.SetValue(k, "", wr.REG_SZ, PROGID)
        with wr.CreateKey(wr.HKEY_CURRENT_USER, r"Software\Classes\%s" % PROGID) as k:
            wr.SetValue(k, "", wr.REG_SZ, "Reborn roster update")
        with wr.CreateKey(wr.HKEY_CURRENT_USER, r"Software\Classes\%s\shell\open\command" % PROGID) as k:
            wr.SetValue(k, "", wr.REG_SZ, '"%s" "%%1"' % exe_path)
    except OSError:
        return
    mark_asked()
