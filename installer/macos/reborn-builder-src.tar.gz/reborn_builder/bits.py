"""MSB-first bit fields, absolute bit index from the start of the buffer."""


def rd_bits(buf, bit, n):
    v = 0
    for i in range(n):
        b = bit + i
        v = (v << 1) | ((buf[b >> 3] >> (7 - (b & 7))) & 1)
    return v


def wr_bits(buf, bit, n, val):
    if val < 0 or val >> n:
        raise ValueError("value %d does not fit in %d bits" % (val, n))
    for i in range(n):
        b = bit + i
        mask = 1 << (7 - (b & 7))
        if (val >> (n - 1 - i)) & 1:
            buf[b >> 3] |= mask
        else:
            buf[b >> 3] &= ~mask & 0xFF
