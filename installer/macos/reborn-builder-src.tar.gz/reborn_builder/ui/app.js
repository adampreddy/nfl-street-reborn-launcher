'use strict';

// The page owns no truth. Python hands over one State object and this draws it.
var STATE = null;
var WARN_OPEN = false;

function setWarnOpen(open) {
  WARN_OPEN = open;
  $('warnToggle').setAttribute('aria-expanded', open ? 'true' : 'false');
  show($('warnlist'), open);
}

function $(id) { return document.getElementById(id); }
function api() { return window.pywebview.api; }
function text(el, s) { el.textContent = s == null ? '' : s; }
function show(el, on) { el.hidden = !on; }

var POLL = null, SINCE = 0, STEPSTATE = [];

function drawSteps(state) {
  var ol = $('steps');
  var building = state.phase !== 'idle';
  show(ol, building);
  if (!building) { return; }
  if (ol.children.length !== state.steps.length) {
    ol.innerHTML = '';
    state.steps.forEach(function (name) {
      var li = document.createElement('li');
      li.appendChild(document.createTextNode(name));
      ol.appendChild(li);
    });
  }
  state.steps.forEach(function (name, i) {
    var li = ol.children[i], s = STEPSTATE[i];
    // A finished build has finished every step, whether or not the last poll landed. Without
    // this a completed build can draw eight empty circles, which reads as "nothing happened".
    if (state.phase === 'done' && (!s || s.state !== 'done')) { s = { state: 'done' }; }
    // A failure should show how far it got: everything before the failing step ran, and the
    // failing step is the one to point at. Without this a stop at Compose draws eight blanks.
    if (state.phase === 'failed' && state.failure && !s) {
      var at = state.failure.step_index;
      if (at != null) { s = i < at ? { state: 'done' } : (i === at ? { state: 'bad' } : null); }
    }
    li.setAttribute('data-state', s ? s.state : 'todo');
    var extra = '';
    if (s && s.state === 'done' && s.seconds != null) { extra = ' ' + s.seconds.toFixed(1) + 's'; }
    if (s && s.state === 'now' && s.pct != null) { extra = ' ' + s.pct + '%'; }
    li.firstChild.nodeValue = name + extra;
  });
}

function drawResult(state) {
  var card = $('resultCard');
  show(card, state.phase === 'done' && !!state.result);
  if (card.hidden) { return; }
  var r = state.result;
  card.innerHTML = '';
  // A clean-tree build ends with the playable ISO rebuilt from the tree and read back, so
  // the card names the disc; the tree only stands alone when the disc step was skipped.
  var rebuilt = !!(r.is_root && r.root && r.path !== r.root);
  var head = document.createElement('div');
  head.className = 'head';
  head.textContent = rebuilt ? 'Applied into the clean tree and rebuilt the ISO'
                             : (r.is_root ? 'Applied into the clean tree' : 'Done');
  var name = document.createElement('div');
  name.className = 'meta mono';
  name.textContent = r.name;
  var meta = document.createElement('div');
  meta.className = 'meta';
  meta.textContent = [r.size_text, 'sha256 ' + r.short_sha,
                      r.counts.players + ' players, ' + r.counts.teams + ' teams, '
                      + r.counts.portraits + ' portraits',
                      'base ' + r.base_label].filter(Boolean).join('  -  ');
  card.appendChild(head); card.appendChild(name); card.appendChild(meta);
  if (rebuilt) {
    var tree = document.createElement('div');
    tree.className = 'meta';
    tree.textContent = 'Roster applied into ' + r.root + '; the disc was read back against it.';
    card.appendChild(tree);
  }
  r.notes.forEach(function (n) {
    var p = document.createElement('div');
    p.className = 'note';
    p.textContent = n;
    card.appendChild(p);
  });
  var acts = document.createElement('div');
  acts.className = 'acts';
  acts.appendChild(button('Show in folder', 'ghost', 'show'));
  acts.appendChild(button('Build another', 'btn', 'again'));
  card.appendChild(acts);
}

function drawFailure(state) {
  var card = $('failCard');
  show(card, state.phase === 'failed' && !!state.failure);
  if (card.hidden) { return; }
  var f = state.failure;
  card.innerHTML = '';
  var head = document.createElement('div');
  head.className = 'head';
  head.textContent = 'Stopped at ' + f.step;
  var says = document.createElement('div');
  says.className = 'meta';
  says.textContent = f.sentence;
  var closing = document.createElement('div');
  closing.className = 'meta';
  closing.textContent = f.closing;
  card.appendChild(head); card.appendChild(says); card.appendChild(closing);
  var acts = document.createElement('div');
  acts.className = 'acts';
  acts.appendChild(button('Copy details', 'ghost', 'copy'));
  acts.appendChild(button('OK', 'btn', 'again'));
  card.appendChild(acts);
}

function button(label, cls, act) {
  var b = document.createElement('button');
  b.type = 'button';
  b.className = cls;
  b.textContent = label;
  b.setAttribute('data-act', act);
  return b;
}

function apply(events) {
  events.forEach(function (e) {
    if (e.kind === 'step' && e.state === 'start') { STEPSTATE[e.index] = { state: 'now', pct: null }; }
    else if (e.kind === 'step' && e.state === 'done') { STEPSTATE[e.index] = { state: 'done', seconds: e.seconds }; }
    else if (e.kind === 'bytes') { STEPSTATE[e.index] = { state: 'now', pct: Math.floor(100 * e.done / Math.max(1, e.total)) }; }
    else if (e.kind === 'failed') { STEPSTATE[e.failure.step_index] = { state: 'bad' }; }
  });
  var ending = events.some(function (e) { return e.kind === 'done' || e.kind === 'failed'; });
  if (STATE) { drawSteps(STATE); }
  if (ending) { stopPolling(); refresh(); }
}

function startPolling() {
  SINCE = 0;
  STEPSTATE = [];
  if (POLL) { clearInterval(POLL); }
  POLL = setInterval(function () {
    api().progress(SINCE).then(function (p) { SINCE = p.next; apply(p.events); });
  }, 120);
}

function stopPolling() { if (POLL) { clearInterval(POLL); POLL = null; } }

function copyDetails() {
  api().details_text().then(function (d) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(d.text).catch(function () { reveal(d.text); });
    } else {
      reveal(d.text);
    }
  });
}

function reveal(t) {
  var card = $('failCard');
  if (card.querySelector('pre')) { return; }
  var pre = document.createElement('pre');
  pre.textContent = t;
  card.insertBefore(pre, card.querySelector('.acts'));
}

var ADV_OPEN = false;

function drawAdvanced(state) {
  var block = $('advBlock');
  show(block, state.advanced.available);
  if (block.hidden) { return; }
  if (block.childNodes.length) { return; }          // built once, then left alone
  var a = state.advanced;
  var toggle = document.createElement('button');
  toggle.type = 'button';
  toggle.className = 'disclosure quiet';
  toggle.setAttribute('aria-expanded', 'false');
  toggle.innerHTML = '<span class="caret" aria-hidden="true">&#9654;</span><span>Advanced</span>';
  var body = document.createElement('div');
  body.className = 'adv';
  body.hidden = true;

  var path = document.createElement('div');
  path.className = 'path';
  path.textContent = a.root;

  var acts = document.createElement('div');
  acts.className = 'acts';
  acts.appendChild(button('Apply and build the ISO', 'btn', 'adv-apply'));
  acts.appendChild(button('Dump this disc', 'ghost', 'adv-dump-iso'));
  acts.appendChild(button('Dump the clean tree', 'ghost', 'adv-dump-root'));

  var cmd = document.createElement('pre');
  cmd.className = 'cmd';
  cmd.textContent = 'cd ' + a.base_cwd + '\n' + a.base_command;

  var cmdActs = document.createElement('div');
  cmdActs.className = 'acts';
  cmdActs.appendChild(button('Copy command', 'ghost', 'adv-copy-cmd'));

  var note = document.createElement('div');
  note.className = 'path';
  note.textContent = 'Cutting a base rewrites the clean tree, so it stays a command you run yourself.';

  body.appendChild(path);
  body.appendChild(acts);
  body.appendChild(note);
  body.appendChild(cmd);
  body.appendChild(cmdActs);
  block.appendChild(toggle);
  block.appendChild(body);

  toggle.addEventListener('click', function () {
    ADV_OPEN = !ADV_OPEN;
    toggle.setAttribute('aria-expanded', ADV_OPEN ? 'true' : 'false');
    body.hidden = !ADV_OPEN;
  });
}

function advStatus(msg) { text($('advStatus'), msg); }

function render(state) {
  STATE = state;
  document.title = 'Reborn Builder ' + state.version;

  var sel = $('baseSelect');
  sel.innerHTML = '';
  if (!state.bases.length) {
    var ph = document.createElement('option');
    ph.textContent = 'Choose a base ISO';
    ph.value = '';
    sel.appendChild(ph);
  }
  state.bases.forEach(function (b) {
    var o = document.createElement('option');
    o.value = b.path;
    o.textContent = b.name;
    sel.appendChild(o);
  });
  if (state.base) { sel.value = state.base.path; }

  var bl = $('baseLine');
  text(bl, state.base ? state.base.line : '');
  bl.className = 'cap' + (state.base && !state.base.ok ? ' bad' : '');

  var zone = $('drop');
  zone.classList.toggle('filled', !!(state.update && state.update.ok));
  text($('dropText'), state.update ? state.update.name : 'Drop a .rebornroster here');

  var ul = $('updateLine');
  text(ul, state.update ? (state.update.ok ? state.update.line : state.update.problem) : '');
  ul.className = 'cap' + (state.update && !state.update.ok ? ' bad' : '');

  var fl = $('fitLine');
  text(fl, state.fit.text);
  fl.className = 'cap' + (state.fit.ok === false ? ' bad' : '');

  var warnings = (state.update && state.update.ok) ? state.update.warnings : [];
  show($('warnBlock'), warnings.length > 0);
  text($('warnCount'), warnings.length + (warnings.length === 1 ? ' thing to check'
                                                                : ' things to check'));
  var list = $('warnlist');
  list.innerHTML = '';
  warnings.forEach(function (w) {
    var li = document.createElement('li');
    li.textContent = w;
    list.appendChild(li);
  });
  setWarnOpen(WARN_OPEN && warnings.length > 0);

  var busy = state.phase === 'building';
  // The result and failure cards carry their own buttons (Build another, OK), so the action
  // row would be a second, contradictory Build sitting above them.
  show($('actions'), state.phase === 'idle');
  ['baseSelect', 'baseBrowse', 'updateBrowse'].forEach(function (id) { $(id).disabled = busy; });
  var g = state.gate;
  text($('reason'), g.reason);
  $('build').textContent = g.label;
  $('build').disabled = !g.ok;
  drawSteps(state);
  drawResult(state);
  drawFailure(state);
  drawAdvanced(state);

  var ol2 = $('outLine');
  ol2.innerHTML = '';
  var tgt = state.target || { mode: 'iso', switchable: false };
  if (tgt.mode === 'root' && !busy) {
    ol2.appendChild(document.createTextNode('Applies into ' + tgt.root + ', then rebuilds '
                                            + (tgt.iso || 'the playable ISO') + ' from it in Games -- '
                                            + tgt.note + '  '));
    var toIso = document.createElement('a');
    toIso.href = '#';
    toIso.textContent = 'Build a separate ISO instead';
    toIso.setAttribute('data-act', 'target-iso');
    ol2.appendChild(toIso);
  } else if (state.out.path && !busy) {
    ol2.appendChild(document.createTextNode('Writes ' + state.out.name + ' ' + state.out.note + '  '));
    var a = document.createElement('a');
    a.href = '#';
    a.textContent = 'Change';
    ol2.appendChild(a);
    if (tgt.switchable) {
      ol2.appendChild(document.createTextNode('  '));
      var toRoot = document.createElement('a');
      toRoot.href = '#';
      toRoot.textContent = 'Apply into the clean tree instead';
      toRoot.setAttribute('data-act', 'target-root');
      ol2.appendChild(toRoot);
    }
  }
  show($('texturesLine'), !state.textures.path);
  text($('texturesLine'), state.textures.path ? '' : state.textures.note);

  $('app').setAttribute('data-ready', '1');
  $('app').setAttribute('data-phase', state.phase);
}

function refresh() { return api().state().then(render); }

function wire() {
  $('baseSelect').addEventListener('change', function (e) {
    if (e.target.value) { api().choose_base(e.target.value).then(render); }
  });
  $('baseBrowse').addEventListener('click', function () { api().browse_base().then(render); });
  $('updateBrowse').addEventListener('click', function () { api().browse_update().then(render); });
  $('cancel').addEventListener('click', function () { api().close(); });
  $('warnToggle').addEventListener('click', function () { setWarnOpen(!WARN_OPEN); });
  $('build').addEventListener('click', function () {
    api().build().then(function (r) {
      if (r.started) { startPolling(); }
      refresh();
    });
  });
  document.addEventListener('click', function (e) {
    var act = e.target.getAttribute && e.target.getAttribute('data-act');
    if (act === 'target-root') { e.preventDefault(); api().choose_target('root').then(render); }
    else if (act === 'target-iso') { e.preventDefault(); api().choose_target('iso').then(render); }
    else if (act === 'show') { api().show_in_folder(); }
    else if (act === 'again') { stopPolling(); api().reset().then(render); }
    else if (act === 'copy') { copyDetails(); }
    else if (act === 'adv-apply') {
      api().advanced_apply().then(function (r) {
        advStatus(r.started ? '' : r.reason);
        if (r.started) { startPolling(); }
        refresh();
      });
    }
    else if (act === 'adv-dump-iso' || act === 'adv-dump-root') {
      var which = act === 'adv-dump-iso' ? 'iso' : 'root';
      advStatus('Dumping...');
      api().advanced_dump(which).then(function (r) {
        advStatus(r.ok ? ('Wrote ' + r.path) : r.error);
      });
    }
    else if (act === 'adv-copy-cmd') {
      var pre = document.querySelector('#advBlock .cmd');
      if (navigator.clipboard && pre) {
        navigator.clipboard.writeText(pre.textContent).then(function () { advStatus('Copied.'); },
                                                            function () { advStatus('Select the command above and copy it.'); });
      }
    }
  });
  $('outLine').addEventListener('click', function (e) {
    if (e.target.tagName === 'A') { e.preventDefault(); api().choose_out().then(render); }
  });
}

function dropRefused() {
  var z = $('drop');
  z.classList.add('refused');
  text($('dropText'), 'That is not a .rebornroster file');
  setTimeout(function () { z.classList.remove('refused'); refresh(); }, 2500);
}

window.rb = { refresh: refresh, dropRefused: dropRefused };

function boot() { wire(); refresh(); }

if (window.pywebview && window.pywebview.api) { boot(); }
else { window.addEventListener('pywebviewready', boot); }
