"""EA TDB tables, read from their own field definitions.

Header ('DB' 00 08): +0x08 u32 size, +0x10 u32 table count, +0x18 directory of
{char[4] tag byte-reversed, u32 rel}; tables sit at (0x18 + n*8) + rel.
Table: +0x08 u32 record bytes, +0x0c u32 record bits, +0x14 u16 capacity,
+0x16 u16 count, +0x1c u8 field count; defs at +0x28, 16 B each
{u32 type, u32 start bit, char[4] name byte-reversed, u32 bits}; records follow
the defs. Type 0 = NUL-padded latin-1 string, 1 = blob, else unsigned int.
"""
import struct

from .bits import rd_bits, wr_bits

MAGIC = b"DB\x00\x08"


def _u16(b, o):
    return struct.unpack_from(">H", b, o)[0]


def _u32(b, o):
    return struct.unpack_from(">I", b, o)[0]


def _tag(b, o):
    return b[o:o + 4][::-1].decode("latin1")


class Field:
    __slots__ = ("name", "type", "start", "bits")

    def __init__(self, name, type_, start, bits):
        self.name, self.type, self.start, self.bits = name, type_, start, bits

    @property
    def is_string(self):
        return self.type == 0

    @property
    def is_blob(self):
        return self.type == 1

    @property
    def width(self):
        return self.bits // 8

    def __repr__(self):
        return "Field(%s type=%d start=%d bits=%d)" % (self.name, self.type, self.start, self.bits)


class Table:
    def __init__(self, name, buf, offset):
        self.name = name
        self.offset = offset
        self.rec_len = _u32(buf, offset + 0x08)
        self.rec_bits = _u32(buf, offset + 0x0c)
        self.capacity = _u16(buf, offset + 0x14)
        self.count = _u16(buf, offset + 0x16)
        nfields = buf[offset + 0x1c]
        self.fields = []
        fo = offset + 0x28
        for _ in range(nfields):
            self.fields.append(Field(_tag(buf, fo + 8), _u32(buf, fo), _u32(buf, fo + 4), _u32(buf, fo + 12)))
            fo += 16
        self.by_name = {f.name: f for f in self.fields}
        self.rec_start = fo

    def rec_off(self, i):
        return self.rec_start + i * self.rec_len

    def get(self, buf, i, name):
        f = self.by_name[name]
        if (f.is_string or f.is_blob) and (f.start % 8 or f.bits % 8):
            raise ValueError("%s.%s: string/blob field is not byte aligned" % (self.name, f.name))
        o = self.rec_off(i)
        if f.is_string:
            return bytes(buf[o + f.start // 8:o + f.start // 8 + f.width]).split(b"\x00")[0].decode("latin1")
        if f.is_blob:
            return bytes(buf[o + f.start // 8:o + f.start // 8 + f.width]).hex()
        return rd_bits(buf, o * 8 + f.start, f.bits)

    def put(self, buf, i, name, value):
        f = self.by_name[name]
        if (f.is_string or f.is_blob) and (f.start % 8 or f.bits % 8):
            raise ValueError("%s.%s: string/blob field is not byte aligned" % (self.name, f.name))
        o = self.rec_off(i)
        if f.is_string:
            raw = str(value).encode("latin1", "strict")
            if len(raw) > f.width:
                raise ValueError("%s: %r is %d characters, the field holds %d" % (name, value, len(raw), f.width))
            buf[o + f.start // 8:o + f.start // 8 + f.width] = raw.ljust(f.width, b"\x00")
            return
        if f.is_blob:
            try:
                raw = bytes.fromhex(str(value))
            except ValueError:
                raise ValueError("%s: blob must be hex" % name)
            if len(raw) != f.width:
                raise ValueError("%s: blob is %d bytes, the field holds %d" % (name, len(raw), f.width))
            buf[o + f.start // 8:o + f.start // 8 + f.width] = raw
            return
        v = int(value)
        if v < 0 or v >> f.bits:
            raise ValueError("%s: %d does not fit in %d bits" % (name, v, f.bits))
        wr_bits(buf, o * 8 + f.start, f.bits, v)

    def record(self, buf, i):
        return {f.name: self.get(buf, i, f.name) for f in self.fields}

    def index(self, buf, key):
        out = {}
        for i in range(self.count):
            k = self.get(buf, i, key)
            if k in out:
                raise ValueError("%s: %s %r appears twice (records %d and %d)" % (self.name, key, k, out[k], i))
            out[k] = i
        return out


class Db:
    def __init__(self, offset, size, tables):
        self.offset, self.size, self.tables = offset, size, tables

    @classmethod
    def parse(cls, buf, offset):
        if bytes(buf[offset:offset + 4]) != MAGIC:
            raise ValueError("no DB header at 0x%x" % offset)
        size = _u32(buf, offset + 0x08)
        n = _u32(buf, offset + 0x10)
        if not 1 <= n <= 256 or offset + size > len(buf):
            raise ValueError("implausible DB header at 0x%x" % offset)
        base = offset + 0x18 + n * 8
        tables = {}
        for i in range(n):
            o = offset + 0x18 + i * 8
            tag = _tag(buf, o)
            if not tag.isalnum():
                raise ValueError("bad table tag at 0x%x" % o)
            start = base + _u32(buf, o + 4)
            if start + 0x28 > len(buf):
                raise ValueError("table %s at 0x%x runs past the end of the buffer" % (tag, start))
            tables[tag] = Table(tag, buf, start)
        return cls(offset, size, tables)


def find_db(buf, required):
    hits, p = [], 0
    while True:
        p = buf.find(MAGIC, p)
        if p < 0:
            break
        try:
            db = Db.parse(buf, p)
            if required <= set(db.tables):
                hits.append(db)
        except (ValueError, struct.error, IndexError):
            pass
        p += 1
    if len(hits) != 1:
        raise LookupError("expected exactly one DB with tables %s, found %d" % (sorted(required), len(hits)))
    return hits[0]
