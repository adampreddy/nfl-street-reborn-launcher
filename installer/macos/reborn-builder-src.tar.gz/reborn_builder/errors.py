class BuildError(Exception):
    """A refusal. `sentence` is plain words for the person; `details` is for the log."""

    def __init__(self, step, sentence, details=""):
        super().__init__(sentence)
        self.step = step
        self.sentence = sentence
        self.details = details
